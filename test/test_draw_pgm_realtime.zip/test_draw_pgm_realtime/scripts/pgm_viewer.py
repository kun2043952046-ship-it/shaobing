#!/usr/bin/env python3
# pgm_viewer.py
#
# 实时 PGM 网页查看器（无 GUI 依赖, 适合 SSH/无桌面环境）:
#   - 订阅 C++ 节点发布的 /realtime_pgm/image (mono8)
#   - 订阅 C++ 节点发布的 /realtime_pgm/cloud (降采样点云),
#     网页在栅格图右侧渲染实时可交互点云侧视图:
#       滚轮缩放 / 拖动平移 / 双击或按钮复位 / 可切换水平轴 (x / y / 距离)
#       用绿色虚线 + 色带可视化 zmin/zmax 范围, 拖动虚线可直接改 zmin/zmax 滑条
#   - 订阅 /Odometry, 网页用透明 canvas 图层在地图之上叠加显示角色位姿
#   - 网页主地图使用持久化历史地图: 最近 history_duration 秒点云累积成的
#     最终地图 (话题 /realtime_pgm/image_history), 车辆位姿和路径均叠加在此地图上
#     累积时按"帧"投票: 同一帧内同一栅格只计一次命中, 仅保留命中次数达到
#     history_min_hits 的栅格, 用于滤除单点噪声/动态目标残影
#   - 路径规划 (Nav2): 在最终地图上单击目标点, 通过
#     nav2_msgs/action/NavigateToPose 递交给 Nav2(bt_navigator);
#     Nav2 负责全局规划(/plan) + 局部跟踪避障(默认行为树 1Hz 重规划);
#     配套 scripts/nav2_bridge.py 将实时占据栅格转成 /map 并发布
#     map->odom / odom->base_link TF, 代价地图由 Nav2 维护
#   - 网页叠加显示: 全局/局部代价地图 (/gcm.png, /lcm.png, RViz 配色:
#     红=致命 100, 紫=内切 99, 蓝绿->黄红=膨胀代价 1~98),
#     全局路径(绿) / 局部路径(黄) / 目标点(红) / 车身位姿(橙框)
#   - 右键地图或"取消导航"按钮可取消当前导航目标
#   - 浏览器访问 http://<本机IP>:1726 查看实时画面
#   - 网页内滑条实时修改 C++ 节点参数:
#       resolution(cm): 滑条值 v -> resolution = v/100    (1..100 -> 0.01..1.00 米/像素)
#       zmin(cm)/zmax(cm): 滑条值 v -> z = v/100 - 4.0    (0..1200 -> -4.0..+8.0 米)
#       dilate(px): 滑条值直接就是膨胀像素数              (0..20)
#       历史保留(s): 滑条值直接就是 history_duration      (1..600)
#       最低命中帧数: 滑条值直接就是 history_min_hits     (1..20)
#   - 每个参数旁都有数值输入框, 可直接键入精确值(m, px, s), 越界自动夹紧,
#     失焦后按设定精度归一化显示; 与滑条双向同步, 回车即生效
#   - 网页内滑条手动调整雷达->车体中心外参 (仅影响本查看器的位姿显示与规划起点):
#       lidar_to_base_x/y(m): 滑条值 v -> 外参 = v/1000   (-2000..2000 -> -2.0..+2.0 米)
#   - 除外参外, 修改通过参数服务写回, 与 ros2 param set 完全等效
#
# 运行:
#   ros2 run test_draw_pgm_realtime pgm_viewer.py
#   然后浏览器打开 http://<本机IP>:1726

import json
import math
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

import cv2
import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.parameter import Parameter
from rclpy.qos import (qos_profile_sensor_data, QoSProfile,
                       QoSReliabilityPolicy, QoSDurabilityPolicy)
from rclpy.action import ActionClient
from rcl_interfaces.msg import ParameterType
from rcl_interfaces.srv import GetParameters, SetParameters
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Odometry, Path, OccupancyGrid
from sensor_msgs.msg import Image, PointCloud2
from sensor_msgs_py import point_cloud2 as pc2
from std_msgs.msg import UInt8MultiArray

try:
    from nav2_msgs.action import NavigateToPose
except ImportError:  # 允许在未安装 nav2 的机器上仅使用网页预览功能
    NavigateToPose = None

HTTP_PORT = 1726

TBAR_RES_MAX = 100  # resolution = v / 100
TBAR_Z_MAX = 1200   # z = v / 100 - 4.0
TBAR_DIL_MAX = 20   # dilate = v
TBAR_EXT_MAX = 2000  # lidar_to_base = v / 1000 (滑条单位 mm)

PAGE = '''<html><meta charset="utf-8"><title>Realtime PGM + PointCloud</title>
<style>.numin{background:#1c1c1c;color:#8cf;border:1px solid #555;border-radius:4px;
padding:1px 4px;width:92px;font:12px monospace}</style>
<body style="font-family:sans-serif;background:#222;color:#ddd;margin:12px">
<h3 style="margin:4px 0">Realtime PGM <span style="font-size:13px;color:#888">+ 实时点云侧视图</span></h3>
<div id="status" style="color:#8c8">connecting...</div>
<div id="pose" style="color:#fa6">pose: waiting odometry ...</div>
<div id="plan" style="color:#8cf;font-size:13px">Nav2 导航: 单击地图发送目标点, 右键地图或按钮取消 (需 with_nav2:=true 启动 Nav2 与 nav2_bridge)</div>
<div style="display:flex;flex-wrap:wrap;gap:18px;align-items:flex-start;margin:10px 0">
  <div>
    <div id="wrap" style="position:relative;display:inline-block">
      <img id="img" src="/image_history.png" style="max-width:100%;image-rendering:pixelated;display:block;cursor:crosshair">
      <canvas id="ov" style="position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none"></canvas>
    </div>
    <div id="historydesc" style="font-size:12px;color:#888;margin-top:4px">最终地图（历史点云累积的俯视占据投影）</div>
    <div style="margin-top:6px">
      <button id="histrefresh" style="background:#333;color:#ddd;border:1px solid #555;border-radius:6px;padding:4px 10px;cursor:pointer">刷新累计图</button>
      <button id="navcancel" style="background:#333;color:#ddd;border:1px solid #555;border-radius:6px;padding:4px 10px;cursor:pointer">取消导航</button>
      <button id="startmove" style="background:#1d5c2a;color:#dfd;border:1px solid #2f8f45;border-radius:6px;padding:4px 10px;cursor:pointer">开始运动</button>
      <button id="stopmove" style="background:#5c1d1d;color:#fdd;border:1px solid #8f2f2f;border-radius:6px;padding:4px 10px;cursor:pointer">停止运动</button>
      <label style="font-size:12px;color:#aaa;margin-left:8px"><input type="checkbox" id="cb_gcm" checked> 全局代价地图</label>
      <label style="font-size:12px;color:#aaa;margin-left:6px"><input type="checkbox" id="cb_lcm" checked> 局部代价地图</label>
      <span style="font-size:12px;color:#777;margin-left:8px">红=致命 紫=内切 蓝绿→黄红=膨胀代价 | 绿线=全局路径 黄线=局部路径 红点=目标</span>
    </div>
    <div id="motionstat" style="font-size:12px;color:#888;margin-top:4px">运动: 未开始（路径规划完成后点“开始运动”）</div>
    <div id="histstat" style="font-size:12px;color:#c96;margin-top:12px">最终地图: 等待 /realtime_pgm/image_history 数据 ...</div>
    <div id="wraph" style="position:relative;display:inline-block;margin-top:4px;display:none">
      <img id="imgh" style="max-width:100%;image-rendering:pixelated;display:block">
      <div style="position:absolute;left:4px;top:4px;font-size:11px;color:#9f9;background:rgba(0,0,0,0.45);padding:1px 6px;border-radius:4px">实时单帧地图（仅预览，不参与规划）</div>
    </div>
  </div>
  <div style="display:flex;flex-direction:column;gap:6px">
    <div style="font-size:13px;color:#aaa">点云侧视图: 滚轮缩放 / 拖动平移 / 拖动绿虚线改 zmin·zmax / 双击复位 <b id="pcinfo" style="color:#8c8"></b></div>
    <div id="pcbox" style="position:relative;width:600px;max-width:96vw;border:1px solid #444;border-radius:8px;background:#111;overflow:hidden">
      <canvas id="pc" style="display:block;width:100%;height:420px;cursor:grab"></canvas>
    </div>
    <div>
      <button id="pcreset" style="background:#333;color:#ddd;border:1px solid #555;border-radius:6px;padding:4px 10px;cursor:pointer">复位视图</button>
      <button id="pcaxis" style="background:#333;color:#ddd;border:1px solid #555;border-radius:6px;padding:4px 10px;cursor:pointer">水平轴: x</button>
      <span style="font-size:12px;color:#777;margin-left:8px">灰点 = zmin~zmax 范围外, 绿点 = 范围内</span>
    </div>
  </div>
</div>
<div style="background:#2a2a2a;padding:12px;border-radius:8px;max-width:640px">
<div>resolution: <input id="n_res" class="numin" type="number" min="0.01" max="1" step="0.01"> m/px</div>
<input id="res" type="range" min="1" max="100" value="5" style="width:100%"><br>
<div>zmin: <input id="n_zmin" class="numin" type="number" min="-4" max="8" step="0.01"> m &nbsp;&nbsp;
     zmax: <input id="n_zmax" class="numin" type="number" min="-4" max="8" step="0.01"> m</div>
<input id="zmin" type="range" min="0" max="1200" value="350" style="width:49%">
<input id="zmax" type="range" min="0" max="1200" value="500" style="width:49%"><br>
<div>dilate: <input id="n_dil" class="numin" type="number" min="0" max="20" step="1"> px</div>
<input id="dil" type="range" min="0" max="20" value="2" style="width:100%">
<div>历史保留: <input id="n_hist" class="numin" type="number" min="1" max="600" step="1"> s &nbsp;&nbsp;
     最低命中帧数: <input id="n_hits" class="numin" type="number" min="1" max="20" step="1"></div>
<input id="hist" type="range" min="1" max="600" value="300" style="width:49%">
<input id="hits" type="range" min="1" max="20" value="2" style="width:49%">
<div style="margin-top:8px;border-top:1px solid #444;padding-top:8px">
  雷达→车体中心外参: x <input id="n_lx" class="numin" type="number" min="-2" max="2" step="0.001"> m &nbsp;&nbsp;
  y <input id="n_ly" class="numin" type="number" min="-2" max="2" step="0.001"> m
  <span style="font-size:12px;color:#777">(影响位姿与规划起点; 上方数值框可直接输入精确值)</span>
</div>
<input id="lx" type="range" min="-2000" max="2000" value="239" style="width:49%">
<input id="ly" type="range" min="-2000" max="2000" value="-158" style="width:49%">
<div style="font-size:12px;color:#777;margin-top:2px">x &gt; 0: 车体中心在雷达前方 &nbsp;&nbsp; y &gt; 0: 车体中心在雷达左方</div>
</div>
<script>
function fmt(){return{
  res:document.getElementById('res').value,
  zmin:document.getElementById('zmin').value,
  zmax:document.getElementById('zmax').value,
  dil:document.getElementById('dil').value,
  hist:document.getElementById('hist').value,
  hits:document.getElementById('hits').value,
  lx:document.getElementById('lx').value,
  ly:document.getElementById('ly').value}}
/* 各参数的数值框配置: 真实值 = 滑条值/sc + off, 边界 lo/hi 为滑条范围 */
var NUMCFG={
  res :{sc:100,  off:0,  lo:1,     hi:100,  dec:2},
  zmin:{sc:100,  off:-4, lo:0,     hi:1200, dec:2},
  zmax:{sc:100,  off:-4, lo:0,     hi:1200, dec:2},
  dil :{sc:1,    off:0,  lo:0,     hi:20,   dec:0},
  hist:{sc:1,    off:0,  lo:1,     hi:600,  dec:0},
  hits:{sc:1,    off:0,  lo:1,     hi:20,   dec:0},
  lx  :{sc:1000, off:0,  lo:-2000, hi:2000, dec:3},
  ly  :{sc:1000, off:0,  lo:-2000, hi:2000, dec:3}};
function numIn(id){return document.getElementById('n_'+id)}
/* 滑条 -> 数值框 */
function syncNum(id){
  var c=NUMCFG[id];
  numIn(id).value=(parseFloat(document.getElementById(id).value)/c.sc+c.off).toFixed(c.dec)}
function syncNums(skip){for(var id in NUMCFG)if(id!==skip)syncNum(id)}
/* 数值框 -> 滑条: 越界夹紧; 正在输入的空串/负号不打断 */
function numChanged(id){
  var c=NUMCFG[id],el=numIn(id);
  if(el.value===''||el.value==='-')return;
  var v=parseFloat(el.value);
  if(!isFinite(v))return;
  v=Math.min(c.hi/c.sc+c.off,Math.max(c.lo/c.sc+c.off,v));
  document.getElementById(id).value=Math.round((v-c.off)*c.sc);
  onChange(id)}
['res','zmin','zmax','dil','hist','hits','lx','ly'].forEach(function(id){
  var el=numIn(id);
  el.addEventListener('input',function(){numChanged(id)});
  el.addEventListener('blur',function(){syncNum(id)})});
function refresh(skip){
  var f=fmt();
  syncNums(skip);
  document.getElementById('historydesc').textContent='最终地图（最近 '+f.hist+' s 点云累积的俯视占据投影）'}
var sendTimer=null;
function onChange(src){
  refresh(src);
  if(sendTimer)clearTimeout(sendTimer);
  sendTimer=setTimeout(function(){
    var f=fmt();
    fetch('/set?res='+f.res+'&zmin='+f.zmin+'&zmax='+f.zmax+'&dil='+f.dil+
          '&hist='+f.hist+'&hits='+f.hits+'&lx='+f.lx+'&ly='+f.ly)
      .then(r=>r.json()).then(j=>{
        document.getElementById('status').textContent =
          j.ok?('OK: res='+(j.res/100).toFixed(2)+' zmin='+(j.zmin/100-4).toFixed(2)+
                ' zmax='+(j.zmax/100-4).toFixed(2)+' dil='+j.dil+
                ' lidar_to_base=('+(j.lx/1000).toFixed(3)+', '+
                (j.ly/1000).toFixed(3)+') m'):('rejected: '+j.msg);
        if(j.ok)applyState(j)})},300)}
['res','zmin','zmax','dil','hist','hits','lx','ly'].forEach(function(id){
  document.getElementById(id).addEventListener('input',function(){onChange()})});
function applyState(s){
  document.getElementById('res').value=s.res;
  document.getElementById('zmin').value=s.zmin;
  document.getElementById('zmax').value=s.zmax;
  document.getElementById('dil').value=s.dil;
  document.getElementById('hist').value=s.hist;
  document.getElementById('hits').value=s.hits;
  if(s.lx!==undefined)document.getElementById('lx').value=s.lx;
  if(s.ly!==undefined)document.getElementById('ly').value=s.ly}
fetch('/state').then(r=>r.json()).then(applyState).then(refresh);

/* ---------- robot pose + planned path overlay (on top of map) ---------- */
var img=document.getElementById('img');
var ov=document.getElementById('ov');
var ctx=ov.getContext('2d');
var lastPose=null;
var navData=null;    /* /nav 轮询结果: {status, goal, plan, local_plan, meta} */
var gcmImg=null,lcmImg=null;  /* 代价地图 RGBA PNG (后端已对齐底图, 直接铺满) */
function setPlanMsg(text,color){
  var el=document.getElementById('plan');
  el.textContent=text;el.style.color=color}
function w2c(p,meta){
  return{c:(p.x-meta.xmin)/meta.res-0.5,
         r:meta.height-1-((p.y-meta.ymin)/meta.res-0.5)}}
function drawPath(pts,meta,color,widthPx){
  ctx.save();ctx.strokeStyle=color;
  ctx.lineWidth=widthPx;ctx.lineJoin='round';ctx.lineCap='round';
  ctx.beginPath();
  for(var i=0;i<pts.length;i++){
    var q=w2c(pts[i],meta);
    if(i===0)ctx.moveTo(q.c,q.r);else ctx.lineTo(q.c,q.r)}
  ctx.stroke();ctx.restore()}
function drawMark(p,meta,color,fill){
  var q=w2c(p,meta);
  ctx.beginPath();ctx.arc(q.c,q.r,Math.max(4,ov.width/90),0,Math.PI*2);
  if(fill){ctx.fillStyle=color;ctx.fill()}
  ctx.strokeStyle=color;ctx.lineWidth=2;ctx.stroke()}
function drawOverlay(){
  if(!ov.width||!ov.height)return;
  ctx.clearRect(0,0,ov.width,ov.height);
  /* 代价地图 PNG 由后端重投影到底图网格, 尺寸与底图一致, 直接铺满 */
  var cbg=document.getElementById('cb_gcm');
  var cbl=document.getElementById('cb_lcm');
  if(cbg&&cbg.checked&&gcmImg&&
     gcmImg.naturalWidth===ov.width&&gcmImg.naturalHeight===ov.height)
    ctx.drawImage(gcmImg,0,0);
  if(cbl&&cbl.checked&&lcmImg&&
     lcmImg.naturalWidth===ov.width&&lcmImg.naturalHeight===ov.height)
    ctx.drawImage(lcmImg,0,0);
  var meta=navData?navData.meta:null;
  if(meta&&meta.res){
    if(navData&&navData.plan&&navData.plan.length>1)
      drawPath(navData.plan,meta,'rgba(57,211,83,0.9)',Math.max(2,ov.width/240));
    if(navData&&navData.local_plan&&navData.local_plan.length>1)
      drawPath(navData.local_plan,meta,'rgba(255,204,0,0.95)',Math.max(2,ov.width/240));
    if(navData&&navData.goal)
      drawMark(navData.goal,meta,'#ff5544',true)}
  if(!lastPose||!lastPose.ok||
     lastPose.res===null||lastPose.xmin===null||lastPose.ymin===null)return;
  var col=Math.floor((lastPose.x-lastPose.xmin)/lastPose.res);
  var row=ov.height-1-Math.floor((lastPose.y-lastPose.ymin)/lastPose.res);
  if(col<-20||col>ov.width+20||row<-20||row>ov.height+20)return;
  var mapRes=lastPose.res;
  var bodyLength=(lastPose.length||0.60)/mapRes;
  var bodyWidth=(lastPose.width||0.45)/mapRes;
  var halfL=bodyLength/2,halfW=bodyWidth/2;
  var arrowLength=Math.max(bodyLength*0.45,6);
  ctx.save();
  ctx.translate(col,row);
  /* 图像 y 轴向下，因此地图 yaw 在 canvas 中取反。 */
  ctx.rotate(-lastPose.yaw);
  ctx.fillStyle='rgba(255,72,32,0.30)';
  ctx.strokeStyle='#ff4820';
  ctx.lineWidth=Math.max(2,bodyWidth/12);
  ctx.beginPath();
  ctx.rect(-halfL,-halfW,bodyLength,bodyWidth);
  ctx.fill();ctx.stroke();
  /* 车头方向箭头：车体 x 正方向为前方。 */
  ctx.fillStyle='rgba(255,72,32,0.95)';
  ctx.beginPath();
  ctx.moveTo(halfL+arrowLength*0.35,0);
  ctx.lineTo(halfL-arrowLength*0.35,-Math.max(bodyWidth*0.35,4));
  ctx.lineTo(halfL-arrowLength*0.35,Math.max(bodyWidth*0.35,4));
  ctx.closePath();ctx.fill();ctx.stroke();
  ctx.restore()}
/* ---------- 最终地图点击 -> 发送 Nav2 导航目标 ---------- */
document.getElementById('wrap').addEventListener('click',function(e){
  if(!img.naturalWidth||!img.naturalHeight)return;
  var rect=img.getBoundingClientRect();
  if(e.clientX<rect.left||e.clientX>rect.right||
     e.clientY<rect.top||e.clientY>rect.bottom)return;
  var col=Math.floor((e.clientX-rect.left)*img.naturalWidth/rect.width);
  var row=Math.floor((e.clientY-rect.top)*img.naturalHeight/rect.height);
  setPlanMsg('正在发送导航目标到 Nav2 ...','#8cf');
  fetch('/goal?c='+col+'&r='+row).then(function(resp){return resp.json()})
   .then(function(j){
    if(j.ok)setPlanMsg('目标已发送: ('+j.x.toFixed(2)+', '+j.y.toFixed(2)+
      ') m, Nav2 将规划路径并实时避障; 再次点击可更换目标','#5f5');
    else setPlanMsg('发送失败: '+(j.msg||'未知错误'),'#f66');
    pollNav()}).catch(function(){setPlanMsg('目标发送请求失败','#f66')})});
document.getElementById('wrap').addEventListener('contextmenu',function(e){
  var rect=img.getBoundingClientRect();
  if(e.clientX>=rect.left&&e.clientX<=rect.right&&
     e.clientY>=rect.top&&e.clientY<=rect.bottom){
    e.preventDefault();cancelNav()}});
function cancelNav(){
  fetch('/cancel').then(function(r){return r.json()}).then(function(j){
    if(j.ok)setPlanMsg('已请求取消当前导航','#fa6');
    else setPlanMsg(j.msg||'当前没有导航任务','#888');
    pollNav()}).catch(function(){})}
document.getElementById('navcancel').onclick=cancelNav;
/* ---------- 开始/停止运动: 由 C++ 节点按 Nav2 全局路径下发运动帧 ---------- */
function motionCmd(action){
  var el=document.getElementById('motionstat');
  el.textContent='运动: 正在'+(action==='start'?'开始':'停止')+' ...';
  el.style.color='#8cf';
  fetch('/'+action).then(function(r){return r.json()}).then(function(j){
    if(j.ok){
      el.textContent='运动: '+(j.msg||(action==='start'?'已开始':'已停止'));
      el.style.color=(action==='start')?'#5f5':'#fa6';
      setPlanMsg(el.textContent,(action==='start')?'#5f5':'#fa6')}
    else{
      el.textContent='运动: '+(j.msg||'操作失败');
      el.style.color='#f66';
      setPlanMsg('运动指令失败: '+(j.msg||'未知错误'),'#f66')}
    pollMotion()}).catch(function(){
      el.textContent='运动: 请求失败';
      el.style.color='#f66'})}
document.getElementById('startmove').onclick=function(){motionCmd('start')};
document.getElementById('stopmove').onclick=function(){motionCmd('stop')};
function pollMotion(){
  fetch('/motion').then(function(r){return r.json()}).then(function(j){
    if(!j.ok)return;
    var el=document.getElementById('motionstat');
    if(el.style.color==='#8cf')return;   /* 正在执行指令, 不覆盖提示 */
    if(j.active){
      el.textContent='运动: 进行中  control='+j.control+
        '  vx='+j.vx.toFixed(2)+' m/s  vy='+j.vy.toFixed(2)+' m/s';
      el.style.color='#5f5'}
    else if(j.control||j.vx||j.vy){
      el.textContent='运动: 已停止 (control='+j.control+')';
      el.style.color='#fa6'}
    else{
      el.textContent='运动: 未开始（路径规划完成后点“开始运动”）';
      el.style.color='#888'}}).catch(function(){})}
setInterval(pollMotion,500);pollMotion();
document.getElementById('histrefresh').onclick=function(){
  setPlanMsg('正在重建累计图: 清空历史点云并重新累积 ...','#8cf');
  fetch('/refresh_history').then(function(resp){return resp.json()})
   .then(function(j){
     if(j.ok){setPlanMsg('已清空历史点云, 累计图与 Nav2 全局地图正在重建','#5f5')}
     else{setPlanMsg('刷新失败: 目标节点参数服务不可用','#f66')}})
   .catch(function(){setPlanMsg('刷新请求失败','#f66')})};
document.getElementById('cb_gcm').addEventListener('change',drawOverlay);
document.getElementById('cb_lcm').addEventListener('change',drawOverlay);
function pollNav(){
  fetch('/nav').then(function(resp){return resp.json()}).then(function(j){
    navData=j;drawOverlay();
    var el=document.getElementById('plan');
    if(j.status&&j.status!=='idle'){
      el.textContent='Nav2 ['+j.status+']'+
        (j.goal?(' → ('+j.goal.x.toFixed(2)+', '+j.goal.y.toFixed(2)+') m'):'')+
        (j.plan?('  全局路径 '+j.plan.length+' 点'):'')+
        (j.local_plan?('  局部路径 '+j.local_plan.length+' 点'):'');
      el.style.color='#5f5'}
    else{
      el.textContent='Nav2 空闲: 单击地图发送目标点, 右键地图或按钮取消导航';
      el.style.color='#888'}}).catch(function(){})}
setInterval(pollNav,500);pollNav();
/* 代价地图 PNG: 后端重投影到底图网格, 无数据时 404 忽略即可 */
function refreshCostmap(kind){
  var im=new Image();
  im.onload=function(){
    if(kind==='g')gcmImg=im;else lcmImg=im;
    drawOverlay()};
  im.src=(kind==='g'?'/gcm.png':'/lcm.png')+'?t='+Date.now()}
function refreshCostmaps(){refreshCostmap('g');refreshCostmap('l')}
setInterval(refreshCostmaps,1000);refreshCostmaps();
function pollPose(){
  fetch('/pose').then(r=>r.json()).then(function(p){
    lastPose=p;drawOverlay();
    var el=document.getElementById('pose');
    if(p.ok){
      el.textContent='pose: x='+p.x.toFixed(2)+' m  y='+p.y.toFixed(2)+
        ' m  yaw='+(p.yaw*180/Math.PI).toFixed(1)+' deg  ('+p.age+'s ago)';
      el.style.color=(p.age>2)?'#f66':'#fa6';
    }else{
      el.textContent='pose: waiting odometry ...';
      el.style.color='#fa6'}}).catch(function(){})}
var imgh=document.getElementById('imgh');
var histstat=document.getElementById('histstat');
var mapFail=0;
img.onload=function(){
  mapFail=0;
  document.getElementById('status').textContent='live: final map';
  histstat.textContent='实时单帧地图预览（不参与规划）';
  histstat.style.color='#9f9';
  if(img.naturalWidth&&img.naturalHeight&&
     (ov.width!=img.naturalWidth||ov.height!=img.naturalHeight)){
    ov.width=img.naturalWidth;ov.height=img.naturalHeight}
  drawOverlay()};
img.onerror=function(){
  mapFail++;
  document.getElementById('status').textContent='waiting for final map ...';
  if(mapFail>=10){
    histstat.textContent='最终地图: 未收到 /realtime_pgm/image_history ! '
      +'请重新编译并重启 C++ 节点: colcon build --packages-select '
      +'test_draw_pgm_realtime 后重新 ros2 launch, 再刷新本页';
    histstat.style.color='#f66'}};
imgh.onload=function(){document.getElementById('wraph').style.display='inline-block'};
setInterval(function(){
  img.src='/image_history.png?t='+Date.now();
  imgh.src='/image.png?t='+Date.now()},500);
setInterval(pollPose,150);
pollPose();

/* ---------- 右侧: 实时可交互点云侧视图 ---------- */
var pc=document.getElementById('pc'),pctx=pc.getContext('2d');
var cloud=null,pcN=0,pcView=null,pcAxis='x',pcDrag=null,pcLast=null;
function hOf(x,y){
  if(pcAxis=='x')return x;
  if(pcAxis=='y')return y;
  return Math.sqrt(x*x+y*y)}
function Xof(h){return(h-pcView.x0)*pcView.sx}
function Yof(z){return pc.height-(z-pcView.z0)*pcView.sz}
function pcXY(e){
  var r=pc.getBoundingClientRect();
  return{px:(e.clientX-r.left)*pc.width/r.width,
         py:(e.clientY-r.top)*pc.height/r.height}}
function pcResize(){
  var w=Math.round(pc.clientWidth||600);
  if(pc.width!=w){pc.width=w;pc.height=420}}
function pcFit(){
  if(!pcN)return;
  pcResize();
  if(!pc.width)return;
  var lo=1e9,hi=-1e9,zl=1e9,zh=-1e9;
  for(var i=0;i<pcN;i++){
    var x=cloud[3*i],y=cloud[3*i+1],z=cloud[3*i+2],h=hOf(x,y);
    if(h<lo)lo=h;if(h>hi)hi=h;if(z<zl)zl=z;if(z>zh)zh=z}
  var f=fmt(),zmin=f.zmin/100-4,zmax=f.zmax/100-4;
  if(zmin<zl)zl=zmin;if(zmax>zh)zh=zmax;
  if(hi-lo<0.3){lo-=0.15;hi+=0.15}
  if(zh-zl<0.3){zl-=0.15;zh+=0.15}
  var mx=(hi-lo)*0.05,mz=(zh-zl)*0.10;
  pcView={x0:lo-mx,z0:zl-mz,
    sx:pc.width/(hi-lo+2*mx),sz:pc.height/(zh-zl+2*mz)}}
function drawZLine(y,label){
  pctx.save();pctx.strokeStyle='rgba(110,255,150,0.9)';pctx.lineWidth=1;
  pctx.setLineDash([6,4]);pctx.beginPath();
  pctx.moveTo(0,y);pctx.lineTo(pc.width,y);pctx.stroke();
  pctx.setLineDash([]);pctx.fillStyle='#9f9';pctx.font='11px sans-serif';
  pctx.fillText(label,5,y-4);pctx.restore()}
function pcDraw(){
  pcResize();
  if(!pc.width||!pc.height)return;
  pctx.fillStyle='#111';pctx.fillRect(0,0,pc.width,pc.height);
  if(!pcN)return;
  if(!pcView)pcFit();
  if(!pcView)return;
  var f=fmt(),zmin=f.zmin/100-4,zmax=f.zmax/100-4;
  var W=pc.width,H=pc.height;
  /* 1m 网格 */
  var stepX=1;while(pcView.sx*stepX<40)stepX++;
  var stepZ=1;while(pcView.sz*stepZ<40)stepZ++;
  pctx.strokeStyle='rgba(255,255,255,0.06)';pctx.lineWidth=1;
  pctx.beginPath();
  for(var gx=Math.ceil(pcView.x0/stepX)*stepX;
      gx<=pcView.x0+W/pcView.sx;gx+=stepX){
    var pxg=Xof(gx);pctx.moveTo(pxg,0);pctx.lineTo(pxg,H)}
  for(var gz=Math.ceil(pcView.z0/stepZ)*stepZ;
      gz<=pcView.z0+H/pcView.sz;gz+=stepZ){
    var pyg=Yof(gz);pctx.moveTo(0,pyg);pctx.lineTo(W,pyg)}
  pctx.stroke();
  /* zmin~zmax 范围色带 */
  var yz1=Yof(zmax),yz0=Yof(zmin);
  pctx.fillStyle='rgba(90,255,140,0.10)';
  pctx.fillRect(0,yz1,W,yz0-yz1);
  /* 点云: 绿=范围内, 灰=范围外 */
  for(var i=0;i<pcN;i++){
    var x=cloud[3*i],y=cloud[3*i+1],z=cloud[3*i+2];
    var px=Xof(hOf(x,y)),py=Yof(z);
    if(px<-2||px>W+2||py<-2||py>H+2)continue;
    pctx.fillStyle=(z>=zmin&&z<=zmax)?'#5fd35f':'rgba(150,150,150,0.30)';
    pctx.fillRect(px,py,1.6,1.6)}
  drawZLine(yz1,'zmax = '+zmax.toFixed(2)+' m');
  drawZLine(yz0,'zmin = '+zmin.toFixed(2)+' m')}
function pollCloud(){
  fetch('/cloud').then(r=>r.json()).then(function(c){
    if(!c.ok||!c.n){
      document.getElementById('pcinfo').textContent='(等待点云...)';return}
    cloud=new Float32Array(c.pts);pcN=c.n;
    document.getElementById('pcinfo').textContent=c.n+' pts';
    if(!pcView)pcFit();
    pcDraw()}).catch(function(){})}
setInterval(pollCloud,250);pollCloud();
pc.addEventListener('mousedown',function(e){
  if(!pcView||!pcN)return;e.preventDefault();
  var p=pcXY(e),f=fmt();
  var dz1=Math.abs(p.py-Yof(f.zmax/100-4));
  var dz0=Math.abs(p.py-Yof(f.zmin/100-4));
  pcDrag=(dz1<=7&&dz1<=dz0)?'zmax':(dz0<=7?'zmin':'pan');
  pcLast={px:p.px,py:p.py}});
window.addEventListener('mouseup',function(){pcDrag=null});
window.addEventListener('mousemove',function(e){
  if(!pcDrag||!pcView)return;
  var p=pcXY(e);
  if(pcDrag=='pan'){
    pcView.x0-=(p.px-pcLast.px)/pcView.sx;
    pcView.z0-=(p.py-pcLast.py)/pcView.sz;
    pcLast={px:p.px,py:p.py};pcDraw();return}
  var z=Math.min(8,Math.max(-4,(pc.height-p.py)/pcView.sz+pcView.z0));
  var t=Math.min(1200,Math.max(0,Math.round((z+4)*100)));
  var f=fmt();
  if(pcDrag=='zmax'){
    if(t<f.zmin)t=f.zmin;
    document.getElementById('zmax').value=t}
  else{
    if(t>f.zmax)t=f.zmax;
    document.getElementById('zmin').value=t}
  onChange();pcDraw()});
pc.addEventListener('mousemove',function(e){
  if(pcDrag||!pcView||!pcN)return;
  var p=pcXY(e),f=fmt();
  var near=Math.abs(p.py-Yof(f.zmax/100-4))<=7||
    Math.abs(p.py-Yof(f.zmin/100-4))<=7;
  pc.style.cursor=near?'ns-resize':'grab'});
pc.addEventListener('mouseleave',function(){
  if(!pcDrag)pc.style.cursor='grab'});
pc.addEventListener('wheel',function(e){
  if(!pcView||!pcN)return;e.preventDefault();
  var p=pcXY(e),k=e.deltaY<0?1.15:1/1.15;
  var h=p.px/pcView.sx+pcView.x0;
  var z=(pc.height-p.py)/pcView.sz+pcView.z0;
  pcView.sx*=k;pcView.sz*=k;
  pcView.x0=h-p.px/pcView.sx;
  pcView.z0=z-(pc.height-p.py)/pcView.sz;
  pcDraw()},{passive:false});
pc.addEventListener('dblclick',function(){pcView=null;pcFit();pcDraw()});
document.getElementById('pcreset').onclick=function(){pcView=null;pcFit();pcDraw()};
document.getElementById('pcaxis').onclick=function(){
  pcAxis=pcAxis=='x'?'y':(pcAxis=='y'?'r':'x');
  this.textContent='水平轴: '+(pcAxis=='r'?'距离 r':pcAxis);
  pcView=null;pcFit();pcDraw()};
window.addEventListener('resize',function(){pcView=null;pcFit();pcDraw()});
</script></body></html>'''


def to_tbar_resolution(res):
    return int(min(TBAR_RES_MAX, max(1, round(res * 100.0))))


def to_tbar_z(z):
    return int(min(TBAR_Z_MAX, max(0, round((z + 4.0) * 100.0))))


def to_tbar_dilate(d):
    return int(min(TBAR_DIL_MAX, max(0, int(d))))


def from_tbar_resolution(v):
    return v / 100.0


def from_tbar_z(v):
    return v / 100.0 - 4.0


def to_tbar_ext(v):
    return int(min(TBAR_EXT_MAX, max(-TBAR_EXT_MAX, round(v * 1000.0))))


def from_tbar_ext(v):
    return v / 1000.0


def costmap_to_rgba(msg, base_meta, out_w, out_h):
    """nav_msgs/OccupancyGrid 代价地图 -> 与底图对齐的 RGBA 图像.
    RViz costmap 配色: cost 1~98 蓝绿->黄红渐变(JET), 99 内切半径紫,
    100 致命红; cost 0(自由) 与 -1(未知/窗口外) 不上色(透明)."""
    info = msg.info
    res_c = float(info.resolution)
    ox = float(info.origin.position.x)
    oy = float(info.origin.position.y)
    w_c, h_c = int(info.width), int(info.height)
    if res_c <= 0.0 or w_c == 0 or h_c == 0:
        return None
    try:
        data = np.asarray(msg.data, dtype=np.int8).reshape(h_c, w_c)
    except (ValueError, TypeError):
        return None

    res_b = float(base_meta['res'])
    # 底图每个像素中心的世界坐标 -> 代价地图栅格索引
    # (OccupancyGrid data 为行主序, 行 0 对应 origin 所在的底边, 因此
    #  世界 y 直接 floor 即为行索引, 无需再翻转; ys 已处理底图第 0 行在顶部)
    xs = float(base_meta['xmin']) + (np.arange(out_w) + 0.5) * res_b
    ys = float(base_meta['ymin']) + \
        (out_h - 1 - np.arange(out_h) + 0.5) * res_b
    cc = np.floor((xs - ox) / res_c).astype(np.int64)
    rr = np.floor((ys - oy) / res_c).astype(np.int64)
    valid = (cc >= 0) & (cc < w_c) & (rr >= 0) & (rr < h_c)
    cc = np.clip(cc, 0, w_c - 1)
    rr = np.clip(rr, 0, h_c - 1)
    cost = data[np.ix_(rr, cc)]  # (out_h, out_w)
    cost[~valid] = -1

    rgba = np.zeros((out_h, out_w, 4), dtype=np.uint8)
    graded = (cost >= 1) & (cost <= 98)
    if graded.any():
        vals = (cost[graded].astype(np.float32) - 1.0) / 97.0 * 255.0
        colored = cv2.applyColorMap(
            vals.astype(np.uint8).reshape(-1, 1), cv2.COLORMAP_JET)
        rgba[graded, 0] = colored[:, 0, 2]
        rgba[graded, 1] = colored[:, 0, 1]
        rgba[graded, 2] = colored[:, 0, 0]
        alpha = 70 + (cost[graded].astype(np.int32) - 1) * 90 // 97
        rgba[graded, 3] = alpha.astype(np.uint8)
    rgba[cost == 99] = (255, 0, 255, 150)   # 内切半径: 紫
    rgba[cost == 100] = (0, 0, 255, 190)    # 致命障碍: 红
    return rgba


class PgmViewer(Node):

    def __init__(self):
        super().__init__('pgm_viewer')

        self.declare_parameter('image_topic', '/realtime_pgm/image')
        self.declare_parameter('target_node', '/test_draw_pgm_realtime')
        self.declare_parameter('http_port', HTTP_PORT)
        self.declare_parameter('odom_topic', '/Odometry')
        self.declare_parameter('cloud_topic', '/realtime_pgm/cloud')
        self.declare_parameter(
            'history_image_topic', '/realtime_pgm/image_history')
        # ---------- Nav2 导航相关 ----------
        # 导航动作名: 网页点击 -> NavigateToPose -> Nav2 全局规划 + 局部避障
        self.declare_parameter('nav_action_name', 'navigate_to_pose')
        # 全局路径 (planner_server) 与局部路径 (controller_server)
        self.declare_parameter('global_plan_topic', '/plan')
        self.declare_parameter('local_plan_topic', '/local_plan')
        # 全局/局部代价地图 (nav_msgs/OccupancyGrid, Nav2 costmap 发布)
        self.declare_parameter('global_costmap_topic',
                               '/global_costmap/costmap')
        self.declare_parameter('local_costmap_topic',
                               '/local_costmap/costmap')
        # 运动帧下发话题 (由 test_draw_pgm_realtime 节点发布, 8 字节 uint8)
        self.declare_parameter('motion_cmd_topic', '/nav_motion_cmd')
        # 速度量化系数: 必须与 C++ 节点 motion_vx_scale / motion_vy_scale
        # 保持一致, 否则网页回显的速度值不准 (仅影响显示)
        self.declare_parameter('motion_vx_scale', 50.0)
        self.declare_parameter('motion_vy_scale', 50.0)
        # 车体几何与雷达安装外参 (单位: m)
        # 车体长度: 机器人前后方向尺寸, 用于网页绘制方块 (默认 0.60 m)
        self.declare_parameter('robot_length', 0.60)
        # 车体宽度: 机器人左右方向尺寸, 用于网页绘制方块 (默认 0.45 m)
        self.declare_parameter('robot_width', 0.45)
        # 雷达->车体中心外参 x: 车体中心在雷达坐标系下的纵向坐标, >0 表示车体中心在雷达前方 
        self.declare_parameter('lidar_to_base_x', 0.239)
        # 雷达->车体中心外参 y: 车体中心在雷达坐标系下的横向坐标, >0 表示车体中心在雷达左方 
        self.declare_parameter('lidar_to_base_y', -0.158)

        image_topic = self.get_parameter('image_topic').value
        self.target_node = self.get_parameter('target_node').value
        http_port = int(self.get_parameter('http_port').value)
        odom_topic = self.get_parameter('odom_topic').value
        cloud_topic = self.get_parameter('cloud_topic').value
        history_topic = self.get_parameter('history_image_topic').value
        nav_action_name = str(self.get_parameter('nav_action_name').value)
        global_plan_topic = self.get_parameter('global_plan_topic').value
        local_plan_topic = self.get_parameter('local_plan_topic').value
        gcm_topic = self.get_parameter('global_costmap_topic').value
        lcm_topic = self.get_parameter('local_costmap_topic').value
        self.robot_length = float(self.get_parameter('robot_length').value)
        self.robot_width = float(self.get_parameter('robot_width').value)
        self.lidar_to_base_x = float(
            self.get_parameter('lidar_to_base_x').value)
        self.lidar_to_base_y = float(
            self.get_parameter('lidar_to_base_y').value)
        # 运动帧速度量化系数 (与 C++ 节点保持一致)
        self.motion_vx_scale = float(
            self.get_parameter('motion_vx_scale').value)
        self.motion_vy_scale = float(
            self.get_parameter('motion_vy_scale').value)

        # 滑条初值 = 节点默认参数（启动后会再从节点读一次覆盖）
        self.tbar = {
            'res': 5, 'zmin': 350, 'zmax': 500, 'dil': 2,
            'hist': 300, 'hits': 2,
            'lx': to_tbar_ext(self.lidar_to_base_x),
            'ly': to_tbar_ext(self.lidar_to_base_y)}
        self.map_meta = {'xmin': None, 'ymin': None, 'res': None}
        self.latest_image = None
        self.image_lock = threading.Lock()
        self.set_lock = threading.Lock()
        self.latest_odom = None
        self.odom_lock = threading.Lock()
        self.latest_cloud = None
        self.cloud_lock = threading.Lock()
        self.latest_history_image = None
        self.history_lock = threading.Lock()

        # ---------- Nav2 导航状态 ----------
        self.nav_action = nav_action_name
        self.nav_lock = threading.Lock()
        self.nav_status = 'idle'
        self.nav_goal = None     # 最近一次点击的目标点 {x, y} (map 系)
        self.global_path = None  # /plan 最新的全局路径 [{x, y}, ...]
        self.local_path = None   # /local_plan 最新的局部路径 [{x, y}, ...]
        self.goal_handle = None  # NavigateToPose goal handle (用于取消)

        # ---------- 代价地图渲染缓存 (RGBA, 已重投影对齐底图网格) ----------
        self.costmap_lock = threading.Lock()
        self.gcm_rgba = None
        self.lcm_rgba = None

        # ---------- 运动控制状态 (网页"开始/停止运动"按钮) ----------
        # 运动帧由 C++ 节点发布; 这里仅记录并展示最近的指令与节点反馈
        self.motion_lock = threading.Lock()
        # 是否正在执行指令 (请求期间网页不覆盖提示文案)
        self.motion_busy = False
        # C++ 节点上报的当前运动帧: control / vx / vy
        self.motion_fb = {'active': False, 'control': 0, 'vx': 0.0, 'vy': 0.0}

        viewer = self
        class Handler(BaseHTTPRequestHandler):
            def reply(self, code, body, ctype='text/html; charset=utf-8'):
                if isinstance(body, str):
                    body = body.encode('utf-8')
                self.send_response(code)
                self.send_header('Content-Type', ctype)
                self.send_header('Content-Length', str(len(body)))
                self.send_header('Cache-Control', 'no-cache')
                self.end_headers()
                self.wfile.write(body)

            def do_GET(self):
                parsed = urlparse(self.path)
                q = parse_qs(parsed.query)
                if parsed.path in ('/', '/index.html'):
                    self.reply(200, PAGE)
                elif parsed.path == '/state':
                    with viewer.set_lock:
                        state = dict(viewer.tbar)
                    self.reply(200, json.dumps(state),
                               ctype='application/json')
                elif parsed.path == '/pose':
                    with viewer.odom_lock:
                        odom = dict(viewer.latest_odom) \
                            if viewer.latest_odom is not None else None
                    with viewer.set_lock:
                        meta = dict(viewer.map_meta)
                    with viewer.history_lock:
                        final_shape = None if viewer.latest_history_image is None \
                            else viewer.latest_history_image.shape
                    if odom is None:
                        self.reply(
                            200, json.dumps({'ok': False}),
                            ctype='application/json')
                        return
                    cos_yaw = math.cos(odom['yaw'])
                    sin_yaw = math.sin(odom['yaw'])
                    base_x = odom['x'] + (
                        cos_yaw * viewer.lidar_to_base_x -
                        sin_yaw * viewer.lidar_to_base_y)
                    base_y = odom['y'] + (
                        sin_yaw * viewer.lidar_to_base_x +
                        cos_yaw * viewer.lidar_to_base_y)
                    self.reply(200, json.dumps({
                        'ok': True,
                        'x': base_x,
                        'y': base_y,
                        'yaw': odom['yaw'],
                        'length': viewer.robot_length,
                        'width': viewer.robot_width,
                        'age': round(time.monotonic() - odom['t'], 2),
                        'xmin': meta['xmin'],
                        'ymin': meta['ymin'],
                        'res': meta['res'],
                        'img_width': None if final_shape is None else final_shape[1],
                        'img_height': None if final_shape is None else final_shape[0]}),
                        ctype='application/json')
                elif parsed.path == '/set':
                    try:
                        with viewer.set_lock:
                            node_param_changed = False
                            for key, tag in (('res', 'res'), ('zmin', 'zmin'),
                                            ('zmax', 'zmax'), ('dil', 'dil'),
                                            ('hist', 'hist'), ('hits', 'hits')):
                                if tag in q:
                                    viewer.tbar[key] = int(q[tag][0])
                                    node_param_changed = True
                            if 'lx' in q:
                                viewer.tbar['lx'] = int(q['lx'][0])
                            if 'ly' in q:
                                viewer.tbar['ly'] = int(q['ly'][0])
                            if 'lx' in q or 'ly' in q:
                                # 外参只属于本查看器(影响位姿显示与规划起点), 不下发到 C++ 节点
                                viewer.set_extrinsics(
                                    from_tbar_ext(viewer.tbar['lx']),
                                    from_tbar_ext(viewer.tbar['ly']))
                            ok = viewer.send_params() \
                                if node_param_changed else True
                            state = dict(viewer.tbar)
                        self.reply(200, json.dumps(
                            {'ok': bool(ok), 'msg': '' if ok else 'param service unavailable',
                             'res': state['res'], 'zmin': state['zmin'],
                             'zmax': state['zmax'], 'dil': state['dil'],
                             'hist': state['hist'], 'hits': state['hits'],
                             'lx': state['lx'], 'ly': state['ly']}),
                            ctype='application/json')
                    except ValueError as e:
                        self.reply(400, json.dumps({'ok': False, 'msg': str(e)}),
                                  ctype='application/json')
                elif parsed.path == '/cloud':
                    with viewer.cloud_lock:
                        arr = None if viewer.latest_cloud is None \
                            else viewer.latest_cloud.copy()
                    if arr is None or arr.shape[0] == 0:
                        self.reply(
                            200, json.dumps({'ok': False, 'n': 0}),
                            ctype='application/json')
                        return
                    payload = np.round(arr, 3).ravel().tolist()
                    self.reply(200, json.dumps({
                        'ok': True,
                        'n': int(arr.shape[0]),
                        'pts': payload}),
                        ctype='application/json')
                elif parsed.path == '/goal':
                    try:
                        col = int(q['c'][0])
                        row = int(q['r'][0])
                    except (KeyError, ValueError, IndexError):
                        self.reply(
                            400,
                            json.dumps({'ok': False, 'stage': 'error',
                                        'msg': '参数 c/r 无效'}),
                            ctype='application/json')
                        return
                    self.reply(
                        200, json.dumps(viewer.handle_goal(col, row)),
                        ctype='application/json')
                elif parsed.path == '/cancel':
                    self.reply(
                        200, json.dumps(viewer.handle_cancel()),
                        ctype='application/json')
                elif parsed.path == '/refresh_history':
                    ok = viewer.request_history_reset()
                    self.reply(200, json.dumps({'ok': bool(ok)}),
                               ctype='application/json')
                elif parsed.path in ('/start', '/stop'):
                    r = viewer.request_motion(parsed.path == '/start')
                    self.reply(200, json.dumps(r),
                               ctype='application/json')
                elif parsed.path == '/motion':
                    self.reply(200, json.dumps(viewer.motion_state()),
                               ctype='application/json')
                elif parsed.path == '/nav':
                    with viewer.nav_lock:
                        status = viewer.nav_status
                        goal = None if viewer.nav_goal is None \
                            else dict(viewer.nav_goal)
                        plan = None if viewer.global_path is None \
                            else list(viewer.global_path)
                        local_plan = None if viewer.local_path is None \
                            else list(viewer.local_path)
                    with viewer.set_lock:
                        meta = dict(viewer.map_meta)
                    with viewer.history_lock:
                        shape = None if viewer.latest_history_image is None \
                            else viewer.latest_history_image.shape
                    meta = dict(meta)
                    meta['height'] = None if shape is None else int(shape[0])
                    meta['width'] = None if shape is None else int(shape[1])
                    self.reply(
                        200,
                        json.dumps({'ok': True, 'status': status,
                                    'goal': goal, 'plan': plan,
                                    'local_plan': local_plan,
                                    'meta': meta}),
                        ctype='application/json')
                elif parsed.path in ('/gcm.png', '/lcm.png'):
                    with viewer.costmap_lock:
                        rgba = viewer.gcm_rgba \
                            if parsed.path == '/gcm.png' else viewer.lcm_rgba
                    if rgba is None:
                        self.reply(404, b'no costmap yet',
                                   ctype='text/plain')
                        return
                    ok, encoded = cv2.imencode('.png', rgba)
                    if not ok:
                        self.reply(500, b'encode failed',
                                   ctype='text/plain')
                        return
                    self.reply(200, encoded.tobytes(), ctype='image/png')
                elif parsed.path == '/image_history.png':
                    with viewer.history_lock:
                        image = None if viewer.latest_history_image is None \
                            else viewer.latest_history_image.copy()
                    if image is None:
                        self.reply(404, b'no image yet', ctype='text/plain')
                        return
                    ok, encoded = cv2.imencode('.png', image)
                    if not ok:
                        self.reply(500, b'encode failed', ctype='text/plain')
                        return
                    self.reply(200, encoded.tobytes(), ctype='image/png')
                elif parsed.path == '/image.png':
                    with viewer.image_lock:
                        image = None if viewer.latest_image is None \
                            else viewer.latest_image.copy()
                    if image is None:
                        self.reply(404, b'no image yet', ctype='text/plain')
                        return
                    ok, encoded = cv2.imencode('.png', image)
                    if not ok:
                        self.reply(500, b'encode failed', ctype='text/plain')
                        return
                    self.reply(200, encoded.tobytes(), ctype='image/png')
                else:
                    self.reply(404, b'not found', ctype='text/plain')

            def log_message(self, fmt, *args):
                pass

        self.http_server = ThreadingHTTPServer(('0.0.0.0', http_port), Handler)
        threading.Thread(target=self.http_server.serve_forever, daemon=True).start()
        self.get_cli = self.create_client(
            GetParameters, self.target_node + '/get_parameters')
        self.set_cli = self.create_client(
            SetParameters, self.target_node + '/set_parameters')

        # Nav2 NavigateToPose 动作客户端: 网页点击发送/取消导航目标
        if NavigateToPose is not None:
            self.nav_client = ActionClient(
                self, NavigateToPose, nav_action_name)
        else:
            self.nav_client = None

        self.sub = self.create_subscription(
            Image, image_topic, self.on_image, qos_profile_sensor_data)
        self.odom_sub = self.create_subscription(
            Odometry, odom_topic, self.on_odom, qos_profile_sensor_data)
        self.cloud_sub = self.create_subscription(
            PointCloud2, cloud_topic, self.on_cloud,
            qos_profile_sensor_data)
        self.history_sub = self.create_subscription(
            Image, history_topic, self.on_history_image,
            qos_profile_sensor_data)

        # Nav2 全局/局部路径与代价地图订阅
        # (volatile + best_effort 订阅对 volatile/reliable、transient_local
        #  发布端都兼容, 避免与 Nav2 costmap 发布 QoS 不匹配收不到数据)
        costmap_qos = QoSProfile(
            depth=1,
            reliability=QoSReliabilityPolicy.BEST_EFFORT,
            durability=QoSDurabilityPolicy.VOLATILE)
        self.global_plan_sub = self.create_subscription(
            Path, global_plan_topic, self.on_global_plan, 10)
        self.local_plan_sub = self.create_subscription(
            Path, local_plan_topic, self.on_local_plan, 10)
        self.gcm_sub = self.create_subscription(
            OccupancyGrid, gcm_topic, self.on_global_costmap, costmap_qos)
        self.lcm_sub = self.create_subscription(
            OccupancyGrid, lcm_topic, self.on_local_costmap, costmap_qos)

        # 运动帧下发话题 (C++ 节点发布, 这里仅回显状态给网页)
        self.motion_cmd_topic = str(
            self.get_parameter('motion_cmd_topic').value)
        self.motion_sub = self.create_subscription(
            UInt8MultiArray, self.motion_cmd_topic, self.on_motion_cmd, 10)

        self.get_logger().info(
            '网页查看器启动: http://<本机IP>:%d  '
            '(image=%s, odom=%s, cloud=%s, history=%s, 目标节点=%s, '
            'nav2=%s, plan=%s/%s, costmap=%s/%s, motion=%s, '
            'body=%.2fx%.2f m, lidar_to_base=(%.2f, %.2f) m)'
            % (http_port, image_topic, odom_topic, cloud_topic,
               history_topic, self.target_node, nav_action_name,
               global_plan_topic, local_plan_topic, gcm_topic, lcm_topic,
               self.motion_cmd_topic,
               self.robot_length, self.robot_width,
               self.lidar_to_base_x, self.lidar_to_base_y))

    # ---------- 图像订阅 ----------
    def on_image(self, msg):
        if msg.encoding != 'mono8':
            self.get_logger().warning(
                '不支持的图像编码: %s' % msg.encoding, throttle_duration_sec=5.0)
            return
        img = np.frombuffer(msg.data, dtype=np.uint8)
        if msg.width * msg.height != img.size:
            self.get_logger().warning('图像尺寸与数据长度不符，丢弃本帧')
            return
        with self.image_lock:
            self.latest_image = img.reshape(msg.height, msg.width).copy()

    def on_history_image(self, msg):
        if msg.encoding != 'mono8':
            self.get_logger().warning(
                '不支持的图像编码: %s' % msg.encoding, throttle_duration_sec=5.0)
            return
        img = np.frombuffer(msg.data, dtype=np.uint8)
        if msg.width * msg.height != img.size:
            self.get_logger().warning('图像尺寸与数据长度不符，丢弃本帧')
            return
        with self.history_lock:
            self.latest_history_image = \
                img.reshape(msg.height, msg.width).copy()

    # ---------- 里程计订阅（角色在 map 系的实时位姿） ----------
    def on_odom(self, msg):
        pos = msg.pose.pose.position
        q = msg.pose.pose.orientation
        yaw = math.atan2(
            2.0 * (q.w * q.z + q.x * q.y),
            1.0 - 2.0 * (q.y * q.y + q.z * q.z))
        with self.odom_lock:
            self.latest_odom = {
                'x': float(pos.x),
                'y': float(pos.y),
                'yaw': float(yaw),
                't': time.monotonic(),
            }

    # ---------- 运动帧订阅 (8 字节: control/shoot/tar_yaw/tar_pitch/vx/vy) ----------
    def on_motion_cmd(self, msg):
        """解析 C++ 节点下发的运动帧, 回显 control / vx / vy 给网页。
        速度字节为 0.5 零点偏移的有符号量, 这里仅做展示用的一致性还原。"""
        data = list(msg.data)
        if len(data) < 8:
            return

        vx_scale = self.motion_vx_scale if self.motion_vx_scale > 0 else 1.0
        vy_scale = self.motion_vy_scale if self.motion_vy_scale > 0 else 1.0

        def vel(index, scale):
            return round(int(data[index]) - 128, 3) / scale

        with self.motion_lock:
            self.motion_fb = {
                'active': bool(data[0]),
                'control': int(data[0]),
                'vx': vel(6, vx_scale),
                'vy': vel(7, vy_scale)}

    # ---------- 点云预览订阅（供网页右侧侧视图渲染） ----------
    def on_cloud(self, msg):
        pts = None
        try:
            structured = pc2.read_points(
                msg, field_names=('x', 'y', 'z'), skip_nans=True)
            pts = np.stack(
                [structured['x'], structured['y'], structured['z']], axis=1)
        except Exception:
            try:
                pts = self._parse_cloud_manual(msg)
            except Exception:
                pts = None
        if pts is None or pts.size == 0:
            self.get_logger().warning(
                '点云解析失败, 丢弃本帧', throttle_duration_sec=5.0)
            return
        with self.cloud_lock:
            self.latest_cloud = pts.astype(np.float32)

    @staticmethod
    def _parse_cloud_manual(msg):
        """不依赖 sensor_msgs_py 的兜底解析 (x/y/z 必须为 float32)."""
        offsets = {}
        for field in msg.fields:
            if field.name in ('x', 'y', 'z') and field.datatype == 7:
                offsets[field.name] = field.offset
        if len(offsets) != 3:
            raise ValueError('缺少 float32 x/y/z 字段')
        dtype = np.dtype({
            'names': ['x', 'y', 'z'],
            'formats': ['<f4', '<f4', '<f4'],
            'offsets': [offsets['x'], offsets['y'], offsets['z']],
            'itemsize': max(int(msg.point_step), 12)})
        arr = np.frombuffer(bytes(msg.data), dtype=dtype)
        mask = np.isfinite(arr['x']) & np.isfinite(arr['y']) \
            & np.isfinite(arr['z'])
        arr = arr[mask]
        return np.stack([arr['x'], arr['y'], arr['z']], axis=1)

    # ==================== 路径规划 (网页点击目标点 -> 车身到目标点 A*) ====================
    @staticmethod
    def _pixel_to_world(col, row, height, meta):
        """图像像素 -> map 系世界坐标 (PGM 第 0 行在顶部, y 轴已翻转)"""
        x = meta['xmin'] + (col + 0.5) * meta['res']
        y = meta['ymin'] + (height - 1 - row + 0.5) * meta['res']
        return x, y

    # ==================== Nav2 导航 (网页点击目标点 -> NavigateToPose) ====================
    @staticmethod
    def _pixel_to_world(col, row, height, meta):
        """图像像素 -> map 系世界坐标 (PGM 第 0 行在顶部, y 轴已翻转)"""
        x = meta['xmin'] + (col + 0.5) * meta['res']
        y = meta['ymin'] + (height - 1 - row + 0.5) * meta['res']
        return x, y

    def _base_pose(self):
        """当前车体中心位姿: /Odometry(雷达原点) + lidar_to_base 外参
        返回 (x, y, yaw, t) 或 None"""
        with self.odom_lock:
            odom = dict(self.latest_odom) \
                if self.latest_odom is not None else None
        if odom is None:
            return None
        cos_yaw = math.cos(odom['yaw'])
        sin_yaw = math.sin(odom['yaw'])
        base_x = odom['x'] + (
            cos_yaw * self.lidar_to_base_x -
            sin_yaw * self.lidar_to_base_y)
        base_y = odom['y'] + (
            sin_yaw * self.lidar_to_base_x +
            cos_yaw * self.lidar_to_base_y)
        return base_x, base_y, odom['yaw'], odom['t']

    def handle_goal(self, col, row):
        """网页单击入口: 点击像素 -> map 系目标点, 递交给 Nav2 NavigateToPose
        (Nav2 负责全局规划与局部避障, 默认行为树会周期重规划)"""
        if self.nav_client is None or NavigateToPose is None:
            return {'ok': False, 'stage': 'error',
                    'msg': 'nav2_msgs 不可用, 请先安装 ros-humble-nav2-msgs'}
        action_type = NavigateToPose
        with self.history_lock:
            image = None if self.latest_history_image is None \
                else self.latest_history_image.copy()
        with self.set_lock:
            meta = dict(self.map_meta)
        base = self._base_pose()

        if image is None:
            return {'ok': False, 'stage': 'error', 'msg': '暂无地图图像'}
        if base is None:
            return {'ok': False, 'stage': 'error',
                    'msg': '暂无车身位姿, 请等待 /Odometry 数据'}
        if meta['res'] is None or meta['xmin'] is None or \
                meta['ymin'] is None:
            return {'ok': False, 'stage': 'error',
                    'msg': '地图参数未同步, 请稍后重试'}

        height, width = image.shape
        if col < 0 or col >= width or row < 0 or row >= height:
            return {'ok': False, 'stage': 'error', 'msg': '点击位置超出地图'}

        x, y = self._pixel_to_world(col, row, height, meta)
        # 目标朝向: 从当前车身位置指向目标点 (Nav2 规划器主要使用位置)
        goal_yaw = math.atan2(y - base[1], x - base[0])

        goal = action_type.Goal()
        goal.pose = PoseStamped()
        goal.pose.header.frame_id = 'map'
        goal.pose.header.stamp = self.get_clock().now().to_msg()
        goal.pose.pose.position.x = float(x)
        goal.pose.pose.position.y = float(y)
        goal.pose.pose.orientation.z = math.sin(0.5 * goal_yaw)
        goal.pose.pose.orientation.w = math.cos(0.5 * goal_yaw)

        if not self.nav_client.wait_for_server(timeout_sec=1.0):
            return {'ok': False, 'stage': 'error',
                    'msg': 'Nav2 动作服务 %s 不可用 '
                           '(检查 Nav2 是否启动并激活)' % self.nav_action}

        self.nav_client.send_goal_async(goal)
        with self.nav_lock:
            self.nav_status = '已发送目标, 等待 Nav2 接受'
            self.nav_goal = {'x': round(x, 3), 'y': round(y, 3)}
            self.goal_handle = None
        self.get_logger().info(
            '导航目标已发送: (%.2f, %.2f) m' % (x, y))
        return {'ok': True, 'stage': 'goal_sent',
                'x': round(x, 3), 'y': round(y, 3)}

    def on_goal_response(self, future):
        """send_goal_async 完成: 记录 goal handle 并挂接结果回调"""
        try:
            handle = future.result()
        except Exception as e:  # noqa: B902
            with self.nav_lock:
                self.nav_status = '目标发送失败: %s' % e
            return
        if handle is None or not handle.accepted:
            with self.nav_lock:
                self.nav_status = 'Nav2 拒绝了目标'
            return
        with self.nav_lock:
            self.goal_handle = handle
            self.nav_status = '导航中'
        handle.get_result_async().add_done_callback(self.on_nav_result)

    def on_nav_result(self, future):
        try:
            result = future.result()
        except Exception as e:  # noqa: B902
            with self.nav_lock:
                self.nav_status = '导航异常: %s' % e
            return
        # GoalStatus: 4 成功 / 5 取消 / 6 中止
        status_text = {4: '已到达目标', 5: '导航已取消',
                       6: '导航失败(中止)'}.get(int(result.status))
        if status_text is None:
            status_text = '导航结束(状态 %s)' % result.status
        with self.nav_lock:
            self.nav_status = status_text
        self.get_logger().info('Nav2: ' + status_text)

    def handle_cancel(self):
        """取消当前导航目标 (网页右键 / 取消导航按钮)"""
        with self.nav_lock:
            handle = self.goal_handle
        if handle is None:
            return {'ok': False, 'stage': 'error',
                    'msg': '当前没有进行中的导航任务'}
        try:
            handle.cancel_goal_async()
        except Exception as e:  # noqa: B902
            return {'ok': False, 'stage': 'error', 'msg': '取消失败: %s' % e}
        with self.nav_lock:
            self.nav_status = '正在取消 ...'
        return {'ok': True, 'stage': 'canceling'}

    # ---------- Nav2 路径订阅 ----------
    @staticmethod
    def _path_to_points(msg):
        return [{'x': round(p.pose.position.x, 3),
                 'y': round(p.pose.position.y, 3)} for p in msg.poses]

    def on_global_plan(self, msg):
        with self.nav_lock:
            self.global_path = self._path_to_points(msg)

    def on_local_plan(self, msg):
        with self.nav_lock:
            self.local_path = self._path_to_points(msg)

    # ---------- Nav2 代价地图订阅 -> 重投影到底图网格后缓存 ----------
    def on_global_costmap(self, msg):
        self.render_costmap(msg, is_global=True)

    def on_local_costmap(self, msg):
        self.render_costmap(msg, is_global=False)

    def render_costmap(self, msg, is_global):
        with self.history_lock:
            shape = None if self.latest_history_image is None \
                else self.latest_history_image.shape
        with self.set_lock:
            meta = dict(self.map_meta)
        if shape is None or meta['res'] is None or \
                meta['xmin'] is None or meta['ymin'] is None:
            return
        rgba = costmap_to_rgba(msg, meta, shape[1], shape[0])
        if rgba is None:
            return
        with self.costmap_lock:
            if is_global:
                self.gcm_rgba = rgba
            else:
                self.lcm_rgba = rgba

    # ---------- 雷达->车体中心外参（网页滑条 / ros2 param set 均可修改） ----------
    def set_extrinsics(self, x, y):
        """更新外参: 同步内部缓存与本节点 ROS 参数, 并立刻反映到网页滑条"""
        self.lidar_to_base_x = float(x)
        self.lidar_to_base_y = float(y)
        try:
            self.set_parameters([
                Parameter('lidar_to_base_x', Parameter.Type.DOUBLE,
                          self.lidar_to_base_x),
                Parameter('lidar_to_base_y', Parameter.Type.DOUBLE,
                          self.lidar_to_base_y)])
        except Exception as e:  # noqa: B902
            self.get_logger().warning('写入外参参数失败: %s' % str(e))
        self.get_logger().info(
            '雷达->车体中心外参已更新: lidar_to_base=(%.3f, %.3f) m'
            % (self.lidar_to_base_x, self.lidar_to_base_y),
            throttle_duration_sec=0.5)

    def sync_extrinsics_from_params(self):
        """反向同步: 支持 ros2 param set /pgm_viewer lidar_to_base_x/y"""
        try:
            x = float(self.get_parameter('lidar_to_base_x').value)
            y = float(self.get_parameter('lidar_to_base_y').value)
        except Exception:  # noqa: B902
            return
        if x == self.lidar_to_base_x and y == self.lidar_to_base_y:
            return
        self.lidar_to_base_x = x
        self.lidar_to_base_y = y
        with self.set_lock:
            self.tbar['lx'] = to_tbar_ext(x)
            self.tbar['ly'] = to_tbar_ext(y)

    # ---------- 参数读取（定期同步滑条 + 地图元数据 xmin/ymin/resolution） ----------
    def fetch_current_params(self, timeout_sec=3.0, quiet=False):
        self.sync_extrinsics_from_params()
        if not self.get_cli.wait_for_service(timeout_sec=timeout_sec):
            if not quiet:
                self.get_logger().warning(
                    '找不到 %s 的参数服务, 滑条使用默认值 '
                    '(请确认 test_draw_pgm_realtime 节点已启动)' % self.target_node)
            return

        req = GetParameters.Request()
        req.names = ['resolution', 'zmin', 'zmax', 'dilate', 'xmin', 'ymin',
                     'history_duration', 'history_min_hits']
        future = self.get_cli.call_async(req)

        start = time.time()
        while not future.done() and time.time() - start < timeout_sec:
            time.sleep(0.05)

        if not future.done() or future.result() is None:
            if not quiet:
                self.get_logger().warning('读取参数超时, 滑条使用默认值')
            return

        vals = future.result().values

        def dbl(i, default):
            return vals[i].double_value \
              if vals[i].type == ParameterType.PARAMETER_DOUBLE else default

        def integ(i, default):
            return vals[i].integer_value \
              if vals[i].type == ParameterType.PARAMETER_INTEGER else default

        with self.set_lock:
            self.tbar['res'] = to_tbar_resolution(dbl(0, 0.05))
            self.tbar['zmin'] = to_tbar_z(dbl(1, -0.5))
            self.tbar['zmax'] = to_tbar_z(dbl(2, 1.0))
            self.tbar['dil'] = to_tbar_dilate(integ(3, 2))
            self.tbar['hist'] = int(min(600, max(1, round(dbl(6, 300)))))
            self.tbar['hits'] = int(min(20, max(1, integ(7, 2))))
            self.map_meta['res'] = dbl(0, None)
            self.map_meta['xmin'] = dbl(4, None)
            self.map_meta['ymin'] = dbl(5, None)

        if not quiet:
            self.get_logger().info(
                '已同步节点当前参数: resolution=%.2f zmin=%.2f zmax=%.2f dilate=%d '
                'history_duration=%ds history_min_hits=%d'
                % (from_tbar_resolution(self.tbar['res']),
                   from_tbar_z(self.tbar['zmin']),
                   from_tbar_z(self.tbar['zmax']),
                   self.tbar['dil'],
                   self.tbar['hist'],
                   self.tbar['hits']))

    # ---------- 后台周期同步（防止外部 ros2 param set 改动 xmin/ymin/resolution） ----------
    def sync_loop(self):
        while rclpy.ok():
            time.sleep(5.0)
            if not rclpy.ok():
                break
            try:
                self.fetch_current_params(timeout_sec=1.0, quiet=True)
            except Exception:
                pass

    # ---------- 参数写入（网页滑条 -> C++ 节点） ----------
    def send_params(self):
        if not self.set_cli.service_is_ready():
            self.get_logger().warning(
                '目标节点参数服务不可用, 跳过本次修改',
                throttle_duration_sec=5.0)
            return False

        req = SetParameters.Request()
        req.parameters = [
            Parameter('resolution', Parameter.Type.DOUBLE,
                      from_tbar_resolution(self.tbar['res'])).to_parameter_msg(),
            Parameter('zmin', Parameter.Type.DOUBLE,
                      from_tbar_z(self.tbar['zmin'])).to_parameter_msg(),
            Parameter('zmax', Parameter.Type.DOUBLE,
                      from_tbar_z(self.tbar['zmax'])).to_parameter_msg(),
            Parameter('dilate', Parameter.Type.INTEGER,
                      self.tbar['dil']).to_parameter_msg(),
            Parameter('history_duration', Parameter.Type.DOUBLE,
                      float(self.tbar['hist'])).to_parameter_msg(),
            Parameter('history_min_hits', Parameter.Type.INTEGER,
                      self.tbar['hits']).to_parameter_msg(),
        ]
        future = self.set_cli.call_async(req)
        future.add_done_callback(self.on_set_done)
        return True

    def on_set_done(self, future):
        try:
            result = future.result()
        except Exception as e:  # noqa: B902
            self.get_logger().warning('参数设置请求失败: %s' % str(e))
            return
        rejected = [r.reason for r in result.results if not r.successful]
        if rejected:
            self.get_logger().warning(
                '节点拒绝了修改(检查 zmin<=zmax 等): ' + '; '.join(rejected),
                throttle_duration_sec=2.0)
        else:
            self.get_logger().info('参数已更新')

    # ---------- 网页"刷新累计图" -> 清空节点历史点云缓冲并重建 ----------
    def request_history_reset(self):
        if not self.set_cli.service_is_ready():
            self.get_logger().warning(
                '目标节点参数服务不可用, 无法刷新累计图',
                throttle_duration_sec=5.0)
            return False

        def call(value, timeout_sec=1.0):
            req = SetParameters.Request()
            req.parameters = [
                Parameter('clear_history', Parameter.Type.BOOL,
                          value).to_parameter_msg()]
            future = self.set_cli.call_async(req)
            start = time.time()
            while not future.done() and time.time() - start < timeout_sec:
                time.sleep(0.02)
            return future.result() if future.done() else None

        result = call(True)
        # 复位为 False, 保证下次点击仍构成有效取值变化
        call(False)
        if result is None:
            self.get_logger().warning(
                '刷新累计图请求超时', throttle_duration_sec=5.0)
            return False
        ok = all(r.successful for r in result.results)
        if ok:
            self.get_logger().info('已触发历史累计图重建(清空历史点云)')
        return ok

    # ---------- 网页"开始运动 / 停止运动" -> C++ 节点下发 8 字节运动帧 ----------
    def request_motion(self, start):
        """置位 C++ 节点的一次性触发参数 (start_motion / stop_motion),
        C++ 节点按 Nav2 全局路径跟随并发布运动帧。
        与 clear_history 相同: 置位后立刻复位, 保证下次点击仍构成有效取值变化。"""
        name = 'start_motion' if start else 'stop_motion'
        if not self.set_cli.service_is_ready():
            return {'ok': False,
                    'msg': 'C++ 节点参数服务不可用, 请确认节点已启动'}

        def call(value, timeout_sec=1.0):
            req = SetParameters.Request()
            req.parameters = [
                Parameter(name, Parameter.Type.BOOL,
                          value).to_parameter_msg()]
            future = self.set_cli.call_async(req)
            begin = time.time()
            while not future.done() and time.time() - begin < timeout_sec:
                time.sleep(0.02)
            return future.result() if future.done() else None

        with self.motion_lock:
            self.motion_busy = True
        try:
            result = call(True)
            call(False)   # 复位为 False, 使下次点击仍为变化
        finally:
            with self.motion_lock:
                self.motion_busy = False

        if result is None:
            return {'ok': False, 'msg': '运动指令请求超时'}

        rejected = [r.reason for r in result.results if not r.successful]
        if rejected:
            return {'ok': False, 'msg': '; '.join(rejected)}

        msg = '已请求开始运动 (按 Nav2 全局路径跟随)' if start \
            else '已请求停止运动 (立即下发 control=0)'
        self.get_logger().info(msg)
        return {'ok': True, 'msg': msg}

    def motion_state(self):
        """返回最近一次运动帧状态, 供网页显示"""
        with self.motion_lock:
            fb = dict(self.motion_fb)
            fb['busy'] = self.motion_busy
        fb['ok'] = True
        return fb


def main():
    rclpy.init()
    node = PgmViewer()

    def spin_until_shutdown():
        try:
            rclpy.spin(node)
        except (KeyboardInterrupt, rclpy.executors.ExternalShutdownException):
            pass

    spin_thread = threading.Thread(target=spin_until_shutdown, daemon=True)
    spin_thread.start()
    node.fetch_current_params()
    threading.Thread(target=node.sync_loop, daemon=True).start()
    try:
        while rclpy.ok():
            time.sleep(0.5)
    except KeyboardInterrupt:
        pass
    finally:
        node.http_server.shutdown()
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()
        spin_thread.join(timeout=2.0)


if __name__ == '__main__':
    main()
