#!/usr/bin/env python3
# nav2_bridge.py
#
# 实时 PGM 链路 -> Nav2 的桥接节点:
#   1. 订阅 /realtime_pgm/image_history (mono8: 0=占据, 其余=未观测),
#      并从 test_draw_pgm_realtime 参数服务同步 xmin/ymin/resolution,
#      转成 nav_msgs/OccupancyGrid 发布到 /map (transient_local, 供 Nav2
#      全局代价地图 static_layer 订阅; 网页"刷新累计图"后 /map 自动重建)
#   2. 订阅 /Odometry (FAST-LIO 输出的雷达位姿), 发布 TF: odom -> base_link,
#      并叠加 lidar_to_base 外参使 base_link 对齐车体中心 (与 pgm_viewer 一致)
#   3. 发布静态 TF: map -> odom (恒等变换; FAST-LIO 无回环, map 与 odom
#      共用同一世界坐标系, 与 pgm_viewer 的坐标约定一致)
#
# 运行: ros2 run test_draw_pgm_realtime nav2_bridge.py
# (realtime_pgm.launch.py 会自动启动本节点)

import math
import threading
import time

import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy
from rclpy.qos import qos_profile_sensor_data
from rclpy.parameter import ParameterType
from rcl_interfaces.srv import GetParameters

from geometry_msgs.msg import TransformStamped
from nav_msgs.msg import Odometry, OccupancyGrid
from sensor_msgs.msg import Image
from tf2_ros import TransformBroadcaster, StaticTransformBroadcaster


class Nav2Bridge(Node):

    def __init__(self):
        super().__init__('nav2_bridge')

        self.declare_parameter('odom_topic', '/Odometry')
        self.declare_parameter('history_image_topic',
                               '/realtime_pgm/image_history')
        self.declare_parameter('map_topic', '/map')
        self.declare_parameter('map_frame', 'map')
        self.declare_parameter('odom_frame', 'odom')
        self.declare_parameter('base_frame', 'base_link')
        self.declare_parameter('target_node', '/test_draw_pgm_realtime')
        # 雷达->车体中心外参 (与 pgm_viewer.py 默认值一致, 单位: m)
        self.declare_parameter('lidar_to_base_x', 0.239)
        self.declare_parameter('lidar_to_base_y', -0.158)

        odom_topic = self.get_parameter('odom_topic').value
        history_topic = self.get_parameter('history_image_topic').value
        map_topic = self.get_parameter('map_topic').value
        self.map_frame = self.get_parameter('map_frame').value
        self.odom_frame = self.get_parameter('odom_frame').value
        self.base_frame = self.get_parameter('base_frame').value
        self.target_node = self.get_parameter('target_node').value
        self.lidar_to_base_x = float(
            self.get_parameter('lidar_to_base_x').value)
        self.lidar_to_base_y = float(
            self.get_parameter('lidar_to_base_y').value)

        self.map_meta = {'res': None, 'xmin': None, 'ymin': None}
        self.latest_image = None
        self.image_lock = threading.Lock()

        # Nav2 static_layer 默认以 transient_local + reliable 订阅 /map,
        # 发布端必须提供 transient_local 才能建立连接
        map_qos = QoSProfile(
            depth=1,
            reliability=QoSReliabilityPolicy.RELIABLE,
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL)
        self.map_pub = self.create_publisher(OccupancyGrid, map_topic, map_qos)

        self.tf_broadcaster = TransformBroadcaster(self)
        self.static_broadcaster = StaticTransformBroadcaster(self)
        self.publish_static_map_odom()

        self.image_sub = self.create_subscription(
            Image, history_topic, self.on_image, qos_profile_sensor_data)
        self.odom_sub = self.create_subscription(
            Odometry, odom_topic, self.on_odom, qos_profile_sensor_data)

        # 周期同步 C++ 节点的 xmin/ymin/resolution (网页滑条可改)
        self.param_cli = self.create_client(
            GetParameters, self.target_node + '/get_parameters')
        self.meta_future = None
        self.last_meta_fetch = 0.0
        # rclpy 里只有 create_timer (create_wall_timer 是 rclcpp 的 API)
        self.meta_timer = self.create_timer(1.0, self.meta_timer_cb)

        self.get_logger().info(
            'Nav2 桥接节点启动: history=%s -> %s (frame: %s->%s->%s), '
            'odom=%s, lidar_to_base=(%.2f, %.2f) m'
            % (history_topic, map_topic, self.map_frame, self.odom_frame,
               self.base_frame, odom_topic,
               self.lidar_to_base_x, self.lidar_to_base_y))

    # ---------- 静态 TF: map -> odom (恒等) ----------
    def publish_static_map_odom(self):
        msg = TransformStamped()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = self.map_frame
        msg.child_frame_id = self.odom_frame
        msg.transform.rotation.w = 1.0
        self.static_broadcaster.sendTransform(msg)

    # ---------- 里程计 -> TF odom -> base_link ----------
    def on_odom(self, msg):
        pos = msg.pose.pose.position
        q = msg.pose.pose.orientation
        yaw = math.atan2(
            2.0 * (q.w * q.z + q.x * q.y),
            1.0 - 2.0 * (q.y * q.y + q.z * q.z))

        # /Odometry 是雷达原点位姿; lidar_to_base_x/y 是雷达到车体中心的
        # 向量 (表达在雷达系), 与 pgm_viewer.py 的换算完全一致
        cos_yaw = math.cos(yaw)
        sin_yaw = math.sin(yaw)
        base_x = pos.x + (
            cos_yaw * self.lidar_to_base_x - sin_yaw * self.lidar_to_base_y)
        base_y = pos.y + (
            sin_yaw * self.lidar_to_base_x + cos_yaw * self.lidar_to_base_y)

        t = TransformStamped()
        if msg.header.stamp.sec or msg.header.stamp.nanosec:
            t.header.stamp = msg.header.stamp
        else:
            t.header.stamp = self.get_clock().now().to_msg()
        t.header.frame_id = self.odom_frame
        t.child_frame_id = self.base_frame
        t.transform.translation.x = float(base_x)
        t.transform.translation.y = float(base_y)
        t.transform.translation.z = 0.0
        t.transform.rotation.z = math.sin(0.5 * yaw)
        t.transform.rotation.w = math.cos(0.5 * yaw)
        self.tf_broadcaster.sendTransform(t)

    # ---------- 历史占据图 -> /map (OccupancyGrid) ----------
    def on_image(self, msg):
        if msg.encoding != 'mono8':
            self.get_logger().warning(
                '不支持的图像编码: %s' % msg.encoding,
                throttle_duration_sec=5.0)
            return
        img = np.frombuffer(msg.data, dtype=np.uint8)
        if msg.width * msg.height != img.size:
            self.get_logger().warning('图像尺寸与数据长度不符，丢弃本帧')
            return
        img = img.reshape(msg.height, msg.width).copy()
        with self.image_lock:
            self.latest_image = img
        if self.map_meta['res'] is not None:
            self.publish_map(img)

    def publish_map(self, img):
        meta = self.map_meta
        if meta['res'] is None or meta['xmin'] is None or \
                meta['ymin'] is None:
            return
        if self.map_pub.get_subscription_count() == 0:
            return

        height, width = img.shape
        grid = OccupancyGrid()
        grid.header.frame_id = self.map_frame
        grid.header.stamp = self.get_clock().now().to_msg()
        grid.info.resolution = float(meta['res'])
        grid.info.width = int(width)
        grid.info.height = int(height)
        grid.info.origin.position.x = float(meta['xmin'])
        grid.info.origin.position.y = float(meta['ymin'])
        grid.info.origin.orientation.w = 1.0

        # 图像第 0 行在顶部 (对应 ymax), OccupancyGrid 行 0 对应 origin(ymin)
        # 图像语义: 0=占据(C++ 已按 dilate 膨胀), 其余(205)=未观测;
        # 与 pgm_viewer 原有 A* 约定一致, 未观测区域视为自由(0)
        occ = np.where(img > 0, 0, 100).astype(np.int8)
        grid.data = np.flipud(occ).reshape(-1).tolist()
        self.map_pub.publish(grid)

    # ---------- 从 C++ 节点同步 xmin/ymin/resolution ----------
    def meta_timer_cb(self):
        if self.meta_future is not None:
            if not self.meta_future.done():
                return
            future, self.meta_future = self.meta_future, None
            try:
                result = future.result()
            except Exception as e:  # noqa: B902
                self.get_logger().warning(
                    '读取地图参数失败: %s' % str(e),
                    throttle_duration_sec=10.0)
                return

            vals = result.values

            def dbl(i):
                return vals[i].double_value \
                    if vals[i].type == ParameterType.PARAMETER_DOUBLE \
                    else None

            meta = {'res': dbl(0), 'xmin': dbl(1), 'ymin': dbl(2)}
            if meta['res'] is None or meta['xmin'] is None or \
                    meta['ymin'] is None:
                return
            if meta != self.map_meta:
                self.map_meta = meta
                self.get_logger().info(
                    '地图元数据: resolution=%.3f origin=(%.2f, %.2f)'
                    % (meta['res'], meta['xmin'], meta['ymin']))
                with self.image_lock:
                    img = self.latest_image
                if img is not None:
                    self.publish_map(img)
            return

        # 已同步过则每 5 s 刷新一次 (防止外部 ros2 param set 改动)
        if self.map_meta['res'] is not None and \
                time.monotonic() - self.last_meta_fetch < 5.0:
            return
        if not self.param_cli.service_is_ready():
            return

        req = GetParameters.Request()
        req.names = ['resolution', 'xmin', 'ymin']
        self.meta_future = self.param_cli.call_async(req)
        self.last_meta_fetch = time.monotonic()


def main():
    rclpy.init()
    node = Nav2Bridge()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, rclpy.executors.ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
