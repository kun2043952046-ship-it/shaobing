# 一键启动: Livox 驱动 + FAST-LIO + 实时 PGM 绘制节点
#
# 用法一（完整链路: 驱动 + FAST-LIO + 实时PGM）:
#   ros2 launch test_draw_pgm_realtime realtime_pgm.launch.py
#
# 用法二（覆盖参数）:
#   ros2 launch test_draw_pgm_realtime realtime_pgm.launch.py \
#     resolution:=0.05 zmin:=-0.5 zmax:=1.0 dilate:=2 \
#     history_duration:=300.0 history_min_hits:=2
#
# 用法三（FAST-LIO 已单独运行, 只启动 PGM 节点）:
#   ros2 launch test_draw_pgm_realtime realtime_pgm.launch.py with_driver:=false
#
# 用法四（不启动查看窗口, 无桌面/SSH 环境使用）:
#   ros2 launch test_draw_pgm_realtime realtime_pgm.launch.py with_viewer:=false
#
# 注意: 下方 fast_lio / livox_ros_driver2 的 launch 路径以 Ericsii/FAST_LIO_ROS2
# 和官方 livox_ros_driver2 为准, 如果你用的是别的 fork, 按其 README 改这两处。
#
# 一键执行（云端机器上）:
# cd /home/lele/aaaaa_mine_NJIT_Vision_Gen2/Navigation
# source /opt/ros/humble/setup.bash
# source /home/lele/source_code_from_git/ws_livox/install/setup.bash   # 驱动 + fast_lio
# source install/setup.bash                                            # 本包
#
# ros2 launch test_draw_pgm_realtime realtime_pgm.launch.py

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():
    image_topic = LaunchConfiguration('image_topic')
    odom_topic = LaunchConfiguration('odom_topic')
    with_viewer = LaunchConfiguration('with_viewer')
    robot_length = LaunchConfiguration('robot_length')
    robot_width = LaunchConfiguration('robot_width')
    lidar_to_base_x = LaunchConfiguration('lidar_to_base_x')
    lidar_to_base_y = LaunchConfiguration('lidar_to_base_y')


    # 链路开关
    with_driver = LaunchConfiguration('with_driver')
    config_file = LaunchConfiguration('config_file')

    # Nav2 开关与参数文件
    with_nav2 = LaunchConfiguration('with_nav2')
    nav2_params_file = LaunchConfiguration('nav2_params_file')

    # PGM 节点参数
    cloud_topic = LaunchConfiguration('cloud_topic')
    resolution = LaunchConfiguration('resolution')
    zmin = LaunchConfiguration('zmin')
    zmax = LaunchConfiguration('zmax')
    dilate = LaunchConfiguration('dilate')
    xmin = LaunchConfiguration('xmin')
    ymin = LaunchConfiguration('ymin')
    xmax = LaunchConfiguration('xmax')
    ymax = LaunchConfiguration('ymax')
    output_file = LaunchConfiguration('output')
    history_duration = LaunchConfiguration('history_duration')
    history_max_points_per_frame = LaunchConfiguration('history_max_points_per_frame')
    history_min_hits = LaunchConfiguration('history_min_hits')
    history_output = LaunchConfiguration('history_output')
    render_period_ms = LaunchConfiguration('render_period_ms')

    # 导航运动控制 (网页"开始运动" -> 8 字节运动帧)
    motion_topic = LaunchConfiguration('motion_topic')
    motion_control = LaunchConfiguration('motion_control')
    motion_vx_scale = LaunchConfiguration('motion_vx_scale')
    motion_vy_scale = LaunchConfiguration('motion_vy_scale')
    motion_rate_hz = LaunchConfiguration('motion_rate_hz')
    motion_target_speed = LaunchConfiguration('motion_target_speed')
    motion_lookahead = LaunchConfiguration('motion_lookahead')
    motion_yaw_kp = LaunchConfiguration('motion_yaw_kp')
    motion_goal_tolerance = LaunchConfiguration('motion_goal_tolerance')
    motion_max_lateral = LaunchConfiguration('motion_max_lateral')
    motion_slow_radius = LaunchConfiguration('motion_slow_radius')
    motion_min_speed = LaunchConfiguration('motion_min_speed')
    motion_base_to_lidar_x = LaunchConfiguration('motion_base_to_lidar_x')
    motion_base_to_lidar_y = LaunchConfiguration('motion_base_to_lidar_y')

    # 1) Livox 驱动 (CustomMsg 格式, FAST-LIO 必须用 msg_ 系列 launch)
    livox_driver = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(PathJoinSubstitution([
            FindPackageShare('livox_ros_driver2'),
            'launch_ROS2', 'msg_MID360_launch.py'])),
        condition=IfCondition(with_driver))

    # 2) FAST-LIO 建图 (MID360 直接用 avia.yaml: lidar_type=1 即 Livox CustomMsg)
    fastlio = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(PathJoinSubstitution([
            FindPackageShare('fast_lio'), 'launch', 'mapping.launch.py'])),
        launch_arguments={'config_file': config_file}.items(),
        condition=IfCondition(with_driver))

    # 3) 实时 PGM 绘制节点（常驻运行, Ctrl+C 一键停止全部节点）
    pgm_node = Node(
        package='test_draw_pgm_realtime',
        executable='test_draw_pgm_realtime_node',
        output='screen',
        parameters=[{
            'cloud_topic': cloud_topic,
            'resolution': ParameterValue(resolution, value_type=float),
            'zmin': ParameterValue(zmin, value_type=float),
            'zmax': ParameterValue(zmax, value_type=float),
            'dilate': ParameterValue(dilate, value_type=int),
            'xmin': ParameterValue(xmin, value_type=float),
            'ymin': ParameterValue(ymin, value_type=float),
            'xmax': ParameterValue(xmax, value_type=float),
            'ymax': ParameterValue(ymax, value_type=float),
            'output': output_file,
            'history_output': history_output,
            'history_duration': ParameterValue(history_duration, value_type=float),
            'history_max_points_per_frame': ParameterValue(history_max_points_per_frame, value_type=int),
            'history_min_hits': ParameterValue(history_min_hits, value_type=int),
            'render_period_ms': ParameterValue(render_period_ms, value_type=int),

            # 导航运动控制: 网页"开始运动"后按 Nav2 全局路径跟随,
            # 向 motion_topic 发布 8 字节运动帧 (control/shoot/tar_yaw/tar_pitch/vx/vy)
            'motion_topic': motion_topic,
            'motion_control': ParameterValue(motion_control, value_type=int),
            'motion_vx_scale': ParameterValue(motion_vx_scale, value_type=float),
            'motion_vy_scale': ParameterValue(motion_vy_scale, value_type=float),
            'motion_rate_hz': ParameterValue(motion_rate_hz, value_type=float),
            'motion_target_speed': ParameterValue(motion_target_speed, value_type=float),
            'motion_lookahead': ParameterValue(motion_lookahead, value_type=float),
            'motion_yaw_kp': ParameterValue(motion_yaw_kp, value_type=float),
            'motion_goal_tolerance': ParameterValue(motion_goal_tolerance, value_type=float),
            'motion_max_lateral': ParameterValue(motion_max_lateral, value_type=float),
            'motion_slow_radius': ParameterValue(motion_slow_radius, value_type=float),
            'motion_min_speed': ParameterValue(motion_min_speed, value_type=float),
            'motion_base_to_lidar_x': ParameterValue(motion_base_to_lidar_x, value_type=float),
            'motion_base_to_lidar_y': ParameterValue(motion_base_to_lidar_y, value_type=float),
        }])
    # 4) 实时 PGM 查看窗口（需要桌面环境; 无显示器时用 with_viewer:=false 关掉）
    # 注意: 下方 viewer 的参数默认值必须与 scripts/pgm_viewer.py 中
    #       declare_parameter 的默认值保持一致(单一数据源), 否则网页显示值
    #       与代码里看到的值会对不上。
    viewer = Node(
        package='test_draw_pgm_realtime',
        executable='pgm_viewer.py',
        output='screen',
        parameters=[{
            'image_topic': image_topic,
            'odom_topic': odom_topic,
            'target_node': '/test_draw_pgm_realtime',
            'robot_length': ParameterValue(robot_length, value_type=float),
            'robot_width': ParameterValue(robot_width, value_type=float),
            'lidar_to_base_x': ParameterValue(lidar_to_base_x, value_type=float),
            'lidar_to_base_y': ParameterValue(lidar_to_base_y, value_type=float),
            # 运动帧回显: 网页订阅该话题显示 control / vx / vy
            'motion_cmd_topic': motion_topic,
            'motion_vx_scale': ParameterValue(motion_vx_scale, value_type=float),
            'motion_vy_scale': ParameterValue(motion_vy_scale, value_type=float),
        }],
        condition=IfCondition(with_viewer))

    # 5) Nav2 桥接节点: 实时占据图 -> /map, /Odometry -> TF(map/odom/base_link)
    #    (始终启动, 不受 with_nav2 影响; Nav2 未启动时只是没人订阅 /map)
    nav2_bridge = Node(
        package='test_draw_pgm_realtime',
        executable='nav2_bridge.py',
        output='screen',
        parameters=[{
            'odom_topic': odom_topic,
            'history_image_topic': '/realtime_pgm/image_history',
            'map_topic': '/map',
            'target_node': '/test_draw_pgm_realtime',
            'lidar_to_base_x': ParameterValue(lidar_to_base_x, value_type=float),
            'lidar_to_base_y': ParameterValue(lidar_to_base_y, value_type=float),
        }])

    # 6) Nav2 导航栈 (controller/planner/behavior/bt_navigator/...):
    #    默认行为树以 1Hz 周期重规划, 配合实时代价地图实现动态避障。
    #    定位由 FAST-LIO /Odometry 提供, 故不启动 AMCL/map_server。
    nav2 = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(PathJoinSubstitution([
            FindPackageShare('nav2_bringup'), 'launch',
            'navigation_launch.py'])),
        launch_arguments={
            'params_file': nav2_params_file,
            'use_sim_time': 'false',
            'autostart': 'true'}.items(),
        condition=IfCondition(with_nav2))


    return LaunchDescription([
        # 链路开关
        DeclareLaunchArgument('with_driver', default_value='true'),
        DeclareLaunchArgument('config_file', default_value='avia.yaml'),

        # PGM 节点参数
        DeclareLaunchArgument('cloud_topic', default_value='/cloud_registered'),
        DeclareLaunchArgument('resolution', default_value='0.05'),
        DeclareLaunchArgument('zmin', default_value='-0.5'),
        DeclareLaunchArgument('zmax', default_value='1.0'),
        DeclareLaunchArgument('dilate', default_value='2'),
        DeclareLaunchArgument('xmin', default_value='-20.0'),
        DeclareLaunchArgument('ymin', default_value='-20.0'),
        DeclareLaunchArgument('xmax', default_value='20.0'),
        DeclareLaunchArgument('ymax', default_value='20.0'),
        DeclareLaunchArgument('output', default_value='/tmp/realtime_map.pgm'),
        DeclareLaunchArgument('history_output', default_value='/tmp/realtime_map_history.pgm'),
        DeclareLaunchArgument('history_duration', default_value='300.0'),
        DeclareLaunchArgument('history_max_points_per_frame', default_value='5000'),
        DeclareLaunchArgument('history_min_hits', default_value='2'),
        DeclareLaunchArgument('render_period_ms', default_value='200'),

        DeclareLaunchArgument('image_topic', default_value='/realtime_pgm/image'),
        DeclareLaunchArgument('odom_topic', default_value='/Odometry'),
        DeclareLaunchArgument('with_viewer', default_value='true'),
        DeclareLaunchArgument('robot_length', default_value='0.60'),
        DeclareLaunchArgument('robot_width', default_value='0.45'),
        # 雷达->车体中心外参 (与 pgm_viewer.py 默认值一致; 由 Livox_Calibration.py 标定)
        DeclareLaunchArgument('lidar_to_base_x', default_value='0.239'),
        DeclareLaunchArgument('lidar_to_base_y', default_value='-0.158'),

        # 导航运动控制: 8 字节运动帧 (control/shoot/tar_yaw/tar_pitch/vx/vy)
        DeclareLaunchArgument('motion_topic', default_value='/nav_motion_cmd'),
        DeclareLaunchArgument('motion_control', default_value='1'),
        DeclareLaunchArgument('motion_vx_scale', default_value='50.0'),
        DeclareLaunchArgument('motion_vy_scale', default_value='50.0'),
        DeclareLaunchArgument('motion_rate_hz', default_value='20.0'),
        DeclareLaunchArgument('motion_target_speed', default_value='0.30'),
        DeclareLaunchArgument('motion_lookahead', default_value='0.45'),
        DeclareLaunchArgument('motion_yaw_kp', default_value='1.20'),
        DeclareLaunchArgument('motion_goal_tolerance', default_value='0.25'),
        DeclareLaunchArgument('motion_max_lateral', default_value='0.0'),
        DeclareLaunchArgument('motion_slow_radius', default_value='0.60'),
        DeclareLaunchArgument('motion_min_speed', default_value='0.08'),
        # 车体中心 -> 雷达原点 (m): 与 lidar_to_base_x/y 互为反向量
        DeclareLaunchArgument(
            'motion_base_to_lidar_x', default_value='-0.239'),
        DeclareLaunchArgument(
            'motion_base_to_lidar_y', default_value='0.158'),

        # Nav2: 关闭时仍发布 /map 与 TF, 但不启动规划/控制节点
        DeclareLaunchArgument('with_nav2', default_value='true'),
        DeclareLaunchArgument('nav2_params_file', default_value=PathJoinSubstitution([
            FindPackageShare('test_draw_pgm_realtime'),
            'config', 'nav2_params.yaml'])),

        livox_driver,
        fastlio,
        pgm_node,
        viewer,
        nav2_bridge,
        nav2,
    ])

######lidar_to_base_x > 0：车体中心在雷达前方
######lidar_to_base_y > 0：车体中心在雷达左方