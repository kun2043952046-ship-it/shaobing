#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <deque>
#include <fstream>
#include <limits>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <sensor_msgs/point_cloud2_iterator.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <nav_msgs/msg/path.hpp>
#include <std_msgs/msg/u_int8_multi_array.hpp>


class RealtimePgmNode : public rclcpp::Node
{
public:
  struct Point
  {
    float x;
    float y;
    float z;
  };

  struct Config
  {
    double resolution;
    double zmin;
    double zmax;
    int dilate;
    double xmin;
    double ymin;
    double xmax;
    double ymax;
    std::string output;
    std::string history_output;
    double history_duration;
    int history_max_points_per_frame;
    int history_min_hits;
  };

  // 带时间戳的点云缓存: 用于历史地图的滑动时间窗累积
  struct TimedCloud
  {
    rclcpp::Time stamp;
    std::shared_ptr<const std::vector<Point>> points;
  };

  RealtimePgmNode()
  : Node("test_draw_pgm_realtime")
  {
    Config initial_config;

    initial_config.resolution =
      declare_parameter<double>("resolution", 0.03);
    initial_config.zmin =
      declare_parameter<double>("zmin", -0.5);
    initial_config.zmax =
      declare_parameter<double>("zmax", 1.0);
    initial_config.dilate =
      declare_parameter<int>("dilate", 1);

    initial_config.xmin =
      declare_parameter<double>("xmin", -20.0);
    initial_config.ymin =
      declare_parameter<double>("ymin", -20.0);
    initial_config.xmax =
      declare_parameter<double>("xmax", 20.0);
    initial_config.ymax =
      declare_parameter<double>("ymax", 20.0);

    initial_config.output =
      declare_parameter<std::string>(
        "output", "/tmp/realtime_map.pgm");

    initial_config.history_output =
      declare_parameter<std::string>(
        "history_output", "/tmp/realtime_map_history.pgm");
    initial_config.history_duration =
      declare_parameter<double>("history_duration", 300.0);
    initial_config.history_max_points_per_frame =
      declare_parameter<int>("history_max_points_per_frame", 5000);
    initial_config.history_min_hits =
      declare_parameter<int>("history_min_hits", 2);

    {
      std::lock_guard<std::mutex> lock(config_mutex_);
      config_ = initial_config;
    }

    cloud_topic_ =
      declare_parameter<std::string>(
        "cloud_topic", "/cloud_registered");

    render_period_ms_ =
      declare_parameter<int>("render_period_ms", 200);

    // 一次性触发参数: 网页"刷新累计图"按钮写入 true 时清空历史缓冲并重建
    declare_parameter<bool>("clear_history", false);

    cloud_preview_topic_ =
      declare_parameter<std::string>(
        "cloud_preview_topic", "/realtime_pgm/cloud");

    cloud_preview_max_points_ =
      declare_parameter<int>("cloud_preview_max_points", 15000);

    history_image_topic_ =
      declare_parameter<std::string>(
        "history_image_topic", "/realtime_pgm/image_history");

    parameter_callback_handle_ =
      add_on_set_parameters_callback(
      std::bind(
        &RealtimePgmNode::parameterCallback,
        this,
        std::placeholders::_1));
    
    // 渲染结果同步发布为 mono8 图像, 供查看窗口显示
    image_topic_ =
      declare_parameter<std::string>("image_topic", "/realtime_pgm/image");

    image_publisher_ =
      create_publisher<sensor_msgs::msg::Image>(image_topic_, 1);

    // ---------------- 导航运动控制 (网页"开始运动"后按 Nav2 全局路径下发) ----------------
    // 下发话题: 每包 8 字节 uint8 数组
    //   [0] control  运动使能 (0=停止 / 1=运动), 导航只用该位
    //   [1] shoot    发射标志位 (导航恒为 0, 保留给视觉/自瞄链路)
    //   [2-3] tar_yaw   高8位 + 低8位 (云台 yaw, 导航恒为 0)
    //   [4-5] tar_pitch 高8位 + 低8位 (云台 pitch, 导航恒为 0)
    //   [6] vx  前进方向速度, 以上电时激光雷达前方为 +x
    //   [7] vy  横移方向速度, 以上电时激光雷达左方为 +y
    motion_topic_ =
      declare_parameter<std::string>(
        "motion_topic", "/nav_motion_cmd");

    // 运动控制输入源: 雷达位姿里程计 + Nav2 全局路径
    odom_topic_ =
      declare_parameter<std::string>("odom_topic", "/Odometry");
    global_plan_topic_ =
      declare_parameter<std::string>("global_plan_topic", "/plan");

    motion_control_ =
      declare_parameter<int>("motion_control", 1);
    motion_vx_scale_ =
      declare_parameter<double>("motion_vx_scale", 50.0);
    motion_vy_scale_ =
      declare_parameter<double>("motion_vy_scale", 50.0);
    motion_rate_hz_ =
      declare_parameter<double>("motion_rate_hz", 20.0);

    // 路径跟随参数
    motion_target_speed_ =
      declare_parameter<double>("motion_target_speed", 0.30);
    motion_lookahead_ =
      declare_parameter<double>("motion_lookahead", 0.45);
    motion_yaw_kp_ =
      declare_parameter<double>("motion_yaw_kp", 1.20);
    motion_goal_tolerance_ =
      declare_parameter<double>("motion_goal_tolerance", 0.25);
    motion_max_lateral_ =
      declare_parameter<double>("motion_max_lateral", 0.0);
    motion_slow_radius_ =
      declare_parameter<double>("motion_slow_radius", 0.60);
    motion_min_speed_ =
      declare_parameter<double>("motion_min_speed", 0.08);
    motion_base_to_lidar_x_ =
      declare_parameter<double>("motion_base_to_lidar_x", -0.239);
    motion_base_to_lidar_y_ =
      declare_parameter<double>("motion_base_to_lidar_y", 0.158);

    // 一次性触发参数: 网页"开始运动"/"停止运动"按钮写入
    declare_parameter<bool>("start_motion", false);
    declare_parameter<bool>("stop_motion", false);

    motion_publisher_ =
      create_publisher<std_msgs::msg::UInt8MultiArray>(
      motion_topic_, rclcpp::QoS(10));

    odom_subscription_ =
      create_subscription<nav_msgs::msg::Odometry>(
      odom_topic_,
      rclcpp::SensorDataQoS(),
      std::bind(
        &RealtimePgmNode::odomCallback,
        this,
        std::placeholders::_1));

    plan_subscription_ =
      create_subscription<nav_msgs::msg::Path>(
      global_plan_topic_,
      10,
      std::bind(
        &RealtimePgmNode::planCallback,
        this,
        std::placeholders::_1));

    createMotionTimer();

    // 降采样点云预览, 供网页查看器绘制可交互点云侧视图
    cloud_preview_publisher_ =
      create_publisher<sensor_msgs::msg::PointCloud2>(
      cloud_preview_topic_, rclcpp::SensorDataQoS());

    // 持久化历史地图图像 (最近 history_duration 秒点云按帧投票累积)
    history_image_publisher_ =
      create_publisher<sensor_msgs::msg::Image>(history_image_topic_, 1);


    cloud_subscription_ =
      create_subscription<sensor_msgs::msg::PointCloud2>(
      cloud_topic_,
      rclcpp::SensorDataQoS(),
      std::bind(
        &RealtimePgmNode::cloudCallback,
        this,
        std::placeholders::_1));

    render_timer_ =
      create_wall_timer(
      std::chrono::milliseconds(render_period_ms_),
      std::bind(
        &RealtimePgmNode::renderTimerCallback,
        this));

    warn_timer_ =
      create_wall_timer(
      std::chrono::seconds(5),
      [this]() {
        std::lock_guard<std::mutex> lock(cloud_mutex_);
        if (!received_cloud_) {
          RCLCPP_WARN(
            get_logger(),
            "尚未收到点云，请检查话题: %s",
            cloud_topic_.c_str());
        }
      });

    RCLCPP_INFO(
      get_logger(),
      "实时 PGM 节点启动: topic=%s, output=%s, render_period=%d ms, "
      "cloud_preview=%s (max %d pts), history_image=%s (keep %.0f s)",
      cloud_topic_.c_str(),
      initial_config.output.c_str(),
      render_period_ms_,
      cloud_preview_topic_.c_str(),
      cloud_preview_max_points_,
      history_image_topic_.c_str(),
      initial_config.history_duration);

    printConfig(initial_config);
  }

private:
  // ---------------- 里程计 (雷达在 map 系的位姿) ----------------
  void odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg)
  {
    const auto & q = msg->pose.pose.orientation;
    const double yaw = std::atan2(
      2.0 * (q.w * q.z + q.x * q.y),
      1.0 - 2.0 * (q.y * q.y + q.z * q.z));

    std::lock_guard<std::mutex> lock(motion_mutex_);
    odom_x_ = msg->pose.pose.position.x;
    odom_y_ = msg->pose.pose.position.y;
    odom_yaw_ = yaw;
    odom_received_ = true;
    odom_stamp_ = msg->header.stamp;
  }

  // ---------------- Nav2 全局路径 (map 系) ----------------
  void planCallback(const nav_msgs::msg::Path::SharedPtr msg)
  {
    std::vector<Point> plan;
    plan.reserve(msg->poses.size());

    for (const auto & pose : msg->poses) {
      plan.push_back(
        Point{
          static_cast<float>(pose.pose.position.x),
          static_cast<float>(pose.pose.position.y),
          0.0F});
    }

    if (plan.empty()) {
      return;
    }

    std::lock_guard<std::mutex> lock(motion_mutex_);
    motion_plan_ = std::move(plan);
    motion_plan_received_ = true;
    motion_plan_stamp_ = msg->header.stamp;
  }

  static bool hasField(
    const sensor_msgs::msg::PointCloud2 & cloud,
    const std::string & field_name)
  {
    for (const auto & field : cloud.fields) {
      if (field.name == field_name) {
        return true;
      }
    }
    return false;
  }

  void cloudCallback(
    const sensor_msgs::msg::PointCloud2::SharedPtr msg)
  {
    if (!hasField(*msg, "x") ||
      !hasField(*msg, "y") ||
      !hasField(*msg, "z"))
    {
      RCLCPP_WARN_THROTTLE(
        get_logger(),
        *get_clock(),
        2000,
        "点云缺少 x/y/z 字段，跳过当前帧");
      return;
    }

    std::vector<Point> new_cloud;
    new_cloud.reserve(
      static_cast<std::size_t>(msg->width) *
      static_cast<std::size_t>(msg->height));

    try {
      sensor_msgs::PointCloud2ConstIterator<float> iter_x(*msg, "x");
      sensor_msgs::PointCloud2ConstIterator<float> iter_y(*msg, "y");
      sensor_msgs::PointCloud2ConstIterator<float> iter_z(*msg, "z");

      for (; iter_x != iter_x.end();
        ++iter_x, ++iter_y, ++iter_z)
      {
        const float x = *iter_x;
        const float y = *iter_y;
        const float z = *iter_z;

        if (std::isfinite(x) &&
          std::isfinite(y) &&
          std::isfinite(z))
        {
          new_cloud.push_back({x, y, z});
        }
      }
    } catch (const std::exception & e) {
      RCLCPP_WARN(
        get_logger(),
        "解析 PointCloud2 失败: %s",
        e.what());
      return;
    }

    publishCloudPreview(new_cloud);

    // 历史缓冲帧降采样, 控制内存占用
    std::vector<Point> history_points;

    int history_max_points_per_frame = 5000;
    {
      std::lock_guard<std::mutex> lock(config_mutex_);
      history_max_points_per_frame = config_.history_max_points_per_frame;
    }

    const std::size_t history_cap =
      static_cast<std::size_t>(
        std::max(1, history_max_points_per_frame));

    if (new_cloud.size() > history_cap) {
      const std::size_t stride =
        (new_cloud.size() + history_cap - 1) / history_cap;

      for (std::size_t i = 0; i < new_cloud.size(); i += stride) {
        history_points.push_back(new_cloud[i]);
      }
    } else {
      history_points = new_cloud;
    }

    const rclcpp::Time now = get_clock()->now();

    {
      std::lock_guard<std::mutex> lock(cloud_mutex_);
      latest_cloud_.swap(new_cloud);
      history_.push_back(
        TimedCloud{
          now,
          std::make_shared<std::vector<Point>>(
            std::move(history_points))});
      pruneHistory(now);
      received_cloud_ = true;
      ++cloud_frames_;
    }
  }

  // 清理超出保留时长的历史点云
  void pruneHistory(const rclcpp::Time & now)
  {
    double history_duration = 300.0;
    {
      std::lock_guard<std::mutex> lock(config_mutex_);
      history_duration = config_.history_duration;
    }

    while (!history_.empty() &&
      (now - history_.front().stamp).seconds() > history_duration)
    {
      history_.pop_front();
    }
  }

  // 发布降采样后的点云预览 (供网页端绘制可交互侧视图)
  void publishCloudPreview(const std::vector<Point> & points)
  {
    if (!cloud_preview_publisher_ ||
      cloud_preview_publisher_->get_subscription_count() == 0)
    {
      return;
    }

    const std::size_t total = points.size();

    if (total == 0) {
      return;
    }

    const std::size_t max_points =
      static_cast<std::size_t>(cloud_preview_max_points_);

    const std::size_t stride =
      (total + max_points - 1) / max_points;

    const std::size_t count =
      (total + stride - 1) / stride;

    sensor_msgs::msg::PointCloud2 preview_msg;
    preview_msg.header.stamp = get_clock()->now();
    preview_msg.header.frame_id = "map";
    preview_msg.height = 1;

    sensor_msgs::PointCloud2Modifier modifier(preview_msg);
    modifier.setPointCloud2FieldsByString(1, "xyz");
    modifier.resize(count);

    sensor_msgs::PointCloud2Iterator<float> iter_x(preview_msg, "x");
    sensor_msgs::PointCloud2Iterator<float> iter_y(preview_msg, "y");
    sensor_msgs::PointCloud2Iterator<float> iter_z(preview_msg, "z");

    for (std::size_t i = 0; i < total; i += stride) {
      *iter_x = points[i].x;
      *iter_y = points[i].y;
      *iter_z = points[i].z;
      ++iter_x;
      ++iter_y;
      ++iter_z;
    }

    cloud_preview_publisher_->publish(preview_msg);
  }

  rcl_interfaces::msg::SetParametersResult parameterCallback(
    const std::vector<rclcpp::Parameter> & parameters)
  {
    Config new_config;
    int preview_max_points = cloud_preview_max_points_;
    int new_motion_control = motion_control_;
    double new_motion_vx_scale = motion_vx_scale_;
    double new_motion_vy_scale = motion_vy_scale_;
    double new_motion_rate_hz = motion_rate_hz_;
    double new_motion_target_speed = motion_target_speed_;
    double new_motion_lookahead = motion_lookahead_;
    double new_motion_yaw_kp = motion_yaw_kp_;
    double new_motion_goal_tolerance = motion_goal_tolerance_;
    double new_motion_max_lateral = motion_max_lateral_;
    double new_motion_slow_radius = motion_slow_radius_;
    double new_motion_min_speed = motion_min_speed_;
    double new_motion_base_to_lidar_x = motion_base_to_lidar_x_;
    double new_motion_base_to_lidar_y = motion_base_to_lidar_y_;

    {
      std::lock_guard<std::mutex> lock(config_mutex_);
      new_config = config_;
      preview_max_points = cloud_preview_max_points_;
    }

    for (const auto & parameter : parameters) {
      const std::string & name = parameter.get_name();

      try {
        if (name == "resolution") {
          new_config.resolution = parameter.as_double();
        } else if (name == "zmin") {
          new_config.zmin = parameter.as_double();
        } else if (name == "zmax") {
          new_config.zmax = parameter.as_double();
        } else if (name == "dilate") {
          new_config.dilate = parameter.as_int();
        } else if (name == "xmin") {
          new_config.xmin = parameter.as_double();
        } else if (name == "ymin") {
          new_config.ymin = parameter.as_double();
        } else if (name == "xmax") {
          new_config.xmax = parameter.as_double();
        } else if (name == "ymax") {
          new_config.ymax = parameter.as_double();
        } else if (name == "output") {
          new_config.output = parameter.as_string();
        } else if (name == "cloud_preview_max_points") {
          preview_max_points = parameter.as_int();
        } else if (name == "history_output") {
          new_config.history_output = parameter.as_string();
        } else if (name == "history_duration") {
          new_config.history_duration = parameter.as_double();
        } else if (name == "history_max_points_per_frame") {
          new_config.history_max_points_per_frame = parameter.as_int();
        } else if (name == "history_min_hits") {
          new_config.history_min_hits = parameter.as_int();
        } else if (name == "clear_history") {
          // 网页"刷新累计图": 置位请求, 由渲染线程清空历史点云
          if (parameter.as_bool()) {
            history_reset_requested_.store(true);
          }
        } else if (name == "motion_control") {
          new_motion_control = parameter.as_int();
        } else if (name == "motion_vx_scale") {
          new_motion_vx_scale = parameter.as_double();
        } else if (name == "motion_vy_scale") {
          new_motion_vy_scale = parameter.as_double();
        } else if (name == "motion_rate_hz") {
          new_motion_rate_hz = parameter.as_double();
        } else if (name == "motion_target_speed") {
          new_motion_target_speed = parameter.as_double();
        } else if (name == "motion_lookahead") {
          new_motion_lookahead = parameter.as_double();
        } else if (name == "motion_yaw_kp") {
          new_motion_yaw_kp = parameter.as_double();
        } else if (name == "motion_goal_tolerance") {
          new_motion_goal_tolerance = parameter.as_double();
        } else if (name == "motion_max_lateral") {
          new_motion_max_lateral = parameter.as_double();
        } else if (name == "motion_slow_radius") {
          new_motion_slow_radius = parameter.as_double();
        } else if (name == "motion_min_speed") {
          new_motion_min_speed = parameter.as_double();
        } else if (name == "motion_base_to_lidar_x") {
          new_motion_base_to_lidar_x = parameter.as_double();
        } else if (name == "motion_base_to_lidar_y") {
          new_motion_base_to_lidar_y = parameter.as_double();
        } else if (name == "start_motion") {
          // 网页"开始运动": 置位请求, 由运动线程启动路径跟随
          if (parameter.as_bool()) {
            motion_start_requested_.store(true);
          }
        } else if (name == "stop_motion") {
          // 网页"停止运动": 置位请求, 由运动线程立即急停
          if (parameter.as_bool()) {
            motion_stop_requested_.store(true);
          }
        }
      } catch (const std::exception & e) {
        rcl_interfaces::msg::SetParametersResult result;
        result.successful = false;
        result.reason = e.what();
        return result;
      }
    }

    rcl_interfaces::msg::SetParametersResult result;

    if (new_config.resolution <= 0.0) {
      result.successful = false;
      result.reason = "resolution 必须大于 0";
      return result;
    }

    constexpr double kZminLimit = -4.0;
    constexpr double kZmaxLimit = 8.0;

    if (new_config.zmin < kZminLimit) {
      result.successful = false;
      result.reason = "zmin 最小支持 -4 米";
      return result;
    }

    if (new_config.zmax > kZmaxLimit) {
      result.successful = false;
      result.reason = "zmax 最大支持 8 米";
      return result;
    }

    if (new_config.zmin > new_config.zmax) {
      result.successful = false;
      result.reason = "zmin 不能大于 zmax";
      return result;
    }

    if (new_config.dilate < 0) {
      result.successful = false;
      result.reason = "dilate 不能小于 0";
      return result;
    }

    if (preview_max_points < 10) {
      result.successful = false;
      result.reason = "cloud_preview_max_points 不能小于 10";
      return result;
    }

    if (new_config.history_duration < 1.0) {
      result.successful = false;
      result.reason = "history_duration 不能小于 1 秒";
      return result;
    }

    if (new_config.history_max_points_per_frame < 100) {
      result.successful = false;
      result.reason = "history_max_points_per_frame 不能小于 100";
      return result;
    }

    if (new_config.history_min_hits < 1 ||
      new_config.history_min_hits > 255)
    {
      result.successful = false;
      result.reason = "history_min_hits 需在 1~255 之间";
      return result;
    }

    if (new_config.xmin >= new_config.xmax ||
      new_config.ymin >= new_config.ymax)
    {
      result.successful = false;
      result.reason = "地图范围必须满足 min < max";
      return result;
    }

    if (new_motion_vx_scale <= 0.0 || new_motion_vy_scale <= 0.0) {
      result.successful = false;
      result.reason = "motion_vx_scale / motion_vy_scale 必须大于 0";
      return result;
    }

    if (new_motion_rate_hz < 1.0 || new_motion_rate_hz > 200.0) {
      result.successful = false;
      result.reason = "motion_rate_hz 需在 1~200 之间";
      return result;
    }

    if (new_motion_target_speed < 0.0) {
      result.successful = false;
      result.reason = "motion_target_speed 不能为负";
      return result;
    }

    if (new_motion_lookahead <= 0.0) {
      result.successful = false;
      result.reason = "motion_lookahead 必须大于 0";
      return result;
    }

    if (new_motion_goal_tolerance <= 0.0) {
      result.successful = false;
      result.reason = "motion_goal_tolerance 必须大于 0";
      return result;
    }

    if (new_motion_slow_radius < new_motion_goal_tolerance) {
      result.successful = false;
      result.reason = "motion_slow_radius 不能小于 motion_goal_tolerance";
      return result;
    }

    if (new_motion_min_speed < 0.0 ||
      new_motion_min_speed > new_motion_target_speed)
    {
      result.successful = false;
      result.reason = "motion_min_speed 需在 0 ~ motion_target_speed 之间";
      return result;
    }

    const bool rate_changed =
      std::fabs(new_motion_rate_hz - motion_rate_hz_) > 1e-6;

    {
      std::lock_guard<std::mutex> lock(config_mutex_);
      config_ = new_config;
      config_changed_ = true;
      cloud_preview_max_points_ = preview_max_points;
    }

    {
      std::lock_guard<std::mutex> lock(motion_mutex_);
      motion_control_ = new_motion_control;
      motion_vx_scale_ = new_motion_vx_scale;
      motion_vy_scale_ = new_motion_vy_scale;
      motion_rate_hz_ = new_motion_rate_hz;
      motion_target_speed_ = new_motion_target_speed;
      motion_lookahead_ = new_motion_lookahead;
      motion_yaw_kp_ = new_motion_yaw_kp;
      motion_goal_tolerance_ = new_motion_goal_tolerance;
      motion_max_lateral_ = new_motion_max_lateral;
      motion_slow_radius_ = new_motion_slow_radius;
      motion_min_speed_ = new_motion_min_speed;
      motion_base_to_lidar_x_ = new_motion_base_to_lidar_x;
      motion_base_to_lidar_y_ = new_motion_base_to_lidar_y;
    }

    if (rate_changed) {
      createMotionTimer();
    }

    RCLCPP_INFO(
      get_logger(),
      "参数已热更新: resolution=%.4f, zmin=%.3f, zmax=%.3f, dilate=%d, "
      "history_duration=%.1f, history_min_hits=%d, "
      "motion(control=%d, speed=%.2f m/s, lookahead=%.2f m, rate=%.1f Hz)",
      new_config.resolution,
      new_config.zmin,
      new_config.zmax,
      new_config.dilate,
      new_config.history_duration,
      new_config.history_min_hits,
      new_motion_control,
      new_motion_target_speed,
      new_motion_lookahead,
      new_motion_rate_hz);

    result.successful = true;
    result.reason = "参数更新成功";
    return result;
  }

  void renderTimerCallback()
  {
    const bool reset_history = history_reset_requested_.exchange(false);

    std::vector<Point> cloud_copy;
    std::deque<TimedCloud> history_copy;
    Config config_copy;

    {
      std::lock_guard<std::mutex> lock(cloud_mutex_);
      if (reset_history) {
        history_.clear();
        RCLCPP_INFO(get_logger(), "历史累计图已清空, 开始重新累积");
      }
      if (!received_cloud_) {
        return;
      }
      cloud_copy = latest_cloud_;
      pruneHistory(get_clock()->now());
      history_copy = history_;
    }

    {
      std::lock_guard<std::mutex> lock(config_mutex_);
      config_copy = config_;
      config_changed_ = false;
    }

    renderPgm(cloud_copy, config_copy);
    renderHistoryPgm(history_copy, config_copy);
  }

  // ==================== 导航运动控制 ====================
  // 组装一帧 8 字节运动数据包并发布:
  //   [0] control  [1] shoot  [2-3] tar_yaw(H/L)  [4-5] tar_pitch(H/L)  [6] vx  [7] vy
  // 导航只使用 control / vx / vy 三个字段, 其余按协议占位填 0。
  void publishMotionFrame(bool control, double vx, double vy)
  {
    double vx_scale = 1.0;
    double vy_scale = 1.0;
    int control_value = 1;
    {
      std::lock_guard<std::mutex> lock(motion_mutex_);
      vx_scale = motion_vx_scale_;
      vy_scale = motion_vy_scale_;
      control_value = motion_control_;
    }

    const uint8_t vx_byte = encodeMotionByte(vx, vx_scale);
    const uint8_t vy_byte = encodeMotionByte(vy, vy_scale);

    std_msgs::msg::UInt8MultiArray msg;
    msg.data.resize(8);
    // control 位: 运动时取参数 motion_control (默认 1), 停车时恒为 0
    msg.data[0] = control ? static_cast<uint8_t>(
      std::clamp(control_value, 0, 255)) : 0U;
    msg.data[1] = 0U;                 // shoot      (导航不涉及)
    msg.data[2] = 0U;                 // tar_yaw    高 8 位 (导航不涉及)
    msg.data[3] = 0U;                 // tar_yaw    低 8 位
    msg.data[4] = 0U;                 // tar_pitch  高 8 位 (导航不涉及)
    msg.data[5] = 0U;                 // tar_pitch  低 8 位
    msg.data[6] = vx_byte;            // vx: 雷达前方为 +x
    msg.data[7] = vy_byte;            // vy: 雷达左方为 +y

    motion_publisher_->publish(msg);
  }

  // 速度(有符号, m/s) -> 单字节无符号量: 0.5 为静止零点, 一个量化步长 = 1/scale
  static uint8_t encodeMotionByte(double value, double scale)
  {
    const double s = (scale > 0.0) ? scale : 1.0;
    const double raw = std::lround(value * s) + 128.0;
    return static_cast<uint8_t>(
      std::clamp(raw, 0.0, 255.0));
  }

  // 按 motion_rate_hz 重建下发定时器 (网页滑条热改频率时调用)
  void createMotionTimer()
  {
    if (motion_timer_) {
      motion_timer_->cancel();
    }

    double rate = 20.0;
    {
      std::lock_guard<std::mutex> lock(motion_mutex_);
      rate = motion_rate_hz_;
    }

    const double period_ms = 1000.0 / std::max(1.0, rate);

    motion_timer_ = create_wall_timer(
      std::chrono::milliseconds(
        std::max(1, static_cast<int>(std::lround(period_ms)))),
      std::bind(&RealtimePgmNode::motionTimerCallback, this));
  }

  void motionTimerCallback()
  {
    // 网页按钮请求: 一次触发, 在这里消费
    const bool start_requested = motion_start_requested_.exchange(false);
    const bool stop_requested = motion_stop_requested_.exchange(false);

    if (start_requested && !stop_requested) {
      startMotion();
    } else if (stop_requested) {
      stopMotion("");
    }

    bool active = false;
    bool odom_ok = false;
    bool plan_ok = false;
    double odom_x = 0.0;
    double odom_y = 0.0;
    double odom_yaw = 0.0;
    std::vector<Point> plan;

    {
      std::lock_guard<std::mutex> lock(motion_mutex_);
      active = motion_active_;
      odom_ok = odom_received_;
      plan_ok = motion_plan_received_;
      odom_x = odom_x_;
      odom_y = odom_y_;
      odom_yaw = odom_yaw_;
      plan = motion_plan_;
    }

    // 未开始运动: 持续下发 control=0 的静止帧, 保证底盘始终被明确约束
    if (!active) {
      publishMotionFrame(false, 0.0, 0.0);
      return;
    }

    if (!odom_ok) {
      stopMotion("未收到里程计 (/Odometry), 无法跟随路径");
      return;
    }

    if (!plan_ok || plan.size() < 2) {
      stopMotion("未收到 Nav2 全局路径 (/plan), 等待重新规划");
      return;
    }

    double vx = 0.0;
    double vy = 0.0;
    const bool arrived = computeFollowCommand(
      plan, odom_x, odom_y, odom_yaw, vx, vy);

    // 到达终点或被判定为偏离路径: 停车
    if (arrived) {
      stopMotion("");
      return;
    }

    publishMotionFrame(true, vx, vy);

    RCLCPP_INFO_THROTTLE(
      get_logger(),
      *get_clock(),
      1000,
      "运动帧: control=1 vx=%.3f m/s vy=%.3f m/s (雷达系, 路径 %zu 点)",
      vx,
      vy,
      plan.size());
  }

  // 路径跟随: 在 map 系取前视点, 换算到雷达系得到 vx/vy
  // 返回 true 表示已到达终点 (应停车)
  bool computeFollowCommand(
    const std::vector<Point> & plan,
    double odom_x,
    double odom_y,
    double odom_yaw,
    double & vx,
    double & vy)
  {
    // 1) 路径末端距离: 用于到达判定与减速
    const double dx_end = plan.back().x - odom_x;
    const double dy_end = plan.back().y - odom_y;
    const double dist_end = std::hypot(dx_end, dy_end);

    if (dist_end <= motion_goal_tolerance_) {
      RCLCPP_INFO(
        get_logger(),
        "已到达目标点, 距离 %.3f m <= 阈值 %.3f m, 停车",
        dist_end,
        motion_goal_tolerance_);
      return true;
    }

    // 2) 前视点: 从路径起点向后找第一个距当前位置超过 lookahead 的点,
    //    同时取路径上离当前位置最近的点用于评估横向偏差
    const double lookahead = std::max(0.05, motion_lookahead_);
    double best_dist = std::numeric_limits<double>::max();
    std::size_t nearest_index = 0;
    bool found_lookahead = false;
    std::size_t lookahead_index = plan.size() - 1;

    for (std::size_t i = 0; i < plan.size(); ++i) {
      const double dx = plan[i].x - odom_x;
      const double dy = plan[i].y - odom_y;
      const double d = std::hypot(dx, dy);

      if (d < best_dist) {
        best_dist = d;
        nearest_index = i;
      }

      if (!found_lookahead && d >= lookahead) {
        found_lookahead = true;
        lookahead_index = i;
      }
    }

    // 前视点不能退到已走过的路径点之前, 避免原地打转
    if (lookahead_index < nearest_index) {
      lookahead_index = nearest_index;
    }

    // 3) 横向偏差保护: 偏差过大说明路径已失效 (被顶开/卡住)
    if (motion_max_lateral_ > 0.0 &&
      best_dist > motion_max_lateral_)
    {
      RCLCPP_WARN_THROTTLE(
        get_logger(),
        *get_clock(),
        2000,
        "偏离全局路径 %.3f m (上限 %.3f m), 停车等待重新规划",
        best_dist,
        motion_max_lateral_);
      return true;
    }

    // 4) 目标速度: 接近终点时按剩余距离线性减速
    double speed = std::clamp(motion_target_speed_, 0.0, 5.0);

    if (motion_slow_radius_ > motion_goal_tolerance_ &&
      dist_end < motion_slow_radius_)
    {
      const double ratio =
        (dist_end - motion_goal_tolerance_) /
        (motion_slow_radius_ - motion_goal_tolerance_);
      speed = std::max(motion_min_speed_, speed * ratio);
    }

    // 5) 前视点在雷达系的水平角 -> 航向闭环 (车头转向 + 横移速度)
    //    车体中心 -> 雷达原点 的平移表达在车体系
    const double cos_yaw = std::cos(odom_yaw);
    const double sin_yaw = std::sin(odom_yaw);
    const double base_x = odom_x +
      cos_yaw * motion_base_to_lidar_x_ - sin_yaw * motion_base_to_lidar_y_;
    const double base_y = odom_y +
      sin_yaw * motion_base_to_lidar_x_ + cos_yaw * motion_base_to_lidar_y_;

    const double dx_t = plan[lookahead_index].x - base_x;
    const double dy_t = plan[lookahead_index].y - base_y;

    // 目标点相对车体的角度 (0 = 正前方, + = 左前方)
    const double alpha = std::atan2(dy_t, dx_t) - odom_yaw;

    // 航向偏差超过 90 度: 目标在身后, 只转向不前冲
    if (std::fabs(alpha) > M_PI_2) {
      vx = 0.0;
    } else {
      vx = speed * std::cos(alpha);
    }

    // 横移速度: 麦轮底盘可直接侧移, 与转向分量共同消除横向偏差
    vy = std::clamp(-motion_yaw_kp_ * alpha * speed,
      -speed, speed);

    return false;
  }

  // 网页"开始运动": 校验里程计与全局路径后进入路径跟随
  void startMotion()
  {
    bool odom_ok = false;
    bool plan_ok = false;
    std::size_t plan_size = 0;
    double dist_end = 0.0;

    {
      std::lock_guard<std::mutex> lock(motion_mutex_);
      odom_ok = odom_received_;
      plan_ok = motion_plan_received_;
      plan_size = motion_plan_.size();

      if (odom_ok && plan_ok && plan_size > 0) {
        dist_end = std::hypot(
          motion_plan_.back().x - odom_x_,
          motion_plan_.back().y - odom_y_);
      }
    }

    if (!odom_ok) {
      RCLCPP_WARN(get_logger(), "无法开始运动: 未收到里程计 (/Odometry)");
      return;
    }

    if (!plan_ok || plan_size < 2) {
      RCLCPP_WARN(
        get_logger(),
        "无法开始运动: 未收到有效的 Nav2 全局路径 (/plan), 请先在地图上点击目标点");
      return;
    }

    if (dist_end <= motion_goal_tolerance_) {
      RCLCPP_INFO(
        get_logger(),
        "当前位置距目标 %.3f m 已在阈值 %.3f m 内, 无需运动",
        dist_end,
        motion_goal_tolerance_);
      publishMotionFrame(false, 0.0, 0.0);
      return;
    }

    {
      std::lock_guard<std::mutex> lock(motion_mutex_);
      motion_active_ = true;
    }

    RCLCPP_INFO(
      get_logger(),
      "开始运动: 跟随全局路径 (%zu 点), 距目标 %.2f m, 目标速度 %.2f m/s",
      plan_size,
      dist_end,
      motion_target_speed_);
  }

  void stopMotion(const char * reason)
  {
    bool was_active = false;
    {
      std::lock_guard<std::mutex> lock(motion_mutex_);
      was_active = motion_active_;
      motion_active_ = false;
    }

    publishMotionFrame(false, 0.0, 0.0);

    if (was_active) {
      if (reason != nullptr && reason[0] != '\0') {
        RCLCPP_WARN(get_logger(), "已停止运动: %s", reason);
      } else {
        RCLCPP_INFO(get_logger(), "已停止运动");
      }
    }
  }

  // 计算地图栅格尺寸并校验上限
  bool computeMapSize(const Config & config, int & width, int & height)
  {
    const double width_f =
      (config.xmax - config.xmin) / config.resolution;
    const double height_f =
      (config.ymax - config.ymin) / config.resolution;

    width = static_cast<int>(std::ceil(width_f));
    height = static_cast<int>(std::ceil(height_f));

    if (width <= 0 || height <= 0) {
      RCLCPP_ERROR_THROTTLE(
        get_logger(),
        *get_clock(),
        2000,
        "PGM 尺寸无效: %d x %d",
        width,
        height);
      return false;
    }

    const std::size_t pixel_count =
      static_cast<std::size_t>(width) *
      static_cast<std::size_t>(height);

    constexpr std::size_t max_pixels = 200000000ULL;

    if (pixel_count > max_pixels) {
      RCLCPP_ERROR_THROTTLE(
        get_logger(),
        *get_clock(),
        2000,
        "PGM 像素数量过大: %zu，请增大 resolution 或缩小地图范围",
        pixel_count);
      return false;
    }

    return true;
  }

  // 单帧点云投影到占据栅格 (z 范围过滤)
  // hit_counts 非空时进入历史累积模式: 借助 occupancy 作为"本帧已命中"标记,
  // 同一帧内同一栅格只计一次命中, 从而抑制单点噪声
  void accumulateCloud(
    const std::vector<Point> & cloud,
    const Config & config,
    int width,
    int height,
    std::vector<uint8_t> & occupancy,
    std::size_t & filtered_points,
    std::vector<uint8_t> * hit_counts = nullptr)
  {
    std::vector<std::size_t> frame_cells;
    if (hit_counts != nullptr) {
      frame_cells.reserve(cloud.size());
    }

    for (const auto & point : cloud) {
      if (point.z < config.zmin ||
        point.z > config.zmax)
      {
        continue;
      }

      const int ix = static_cast<int>(
        std::floor(
          (static_cast<double>(point.x) - config.xmin) /
          config.resolution));

      const int iy = static_cast<int>(
        std::floor(
          (static_cast<double>(point.y) - config.ymin) /
          config.resolution));

      if (ix < 0 || ix >= width ||
        iy < 0 || iy >= height)
      {
        continue;
      }

      const std::size_t index =
        static_cast<std::size_t>(iy) *
        static_cast<std::size_t>(width) +
        static_cast<std::size_t>(ix);

      ++filtered_points;

      if (hit_counts == nullptr) {
        occupancy[index] = 1;
        continue;
      }

      if (occupancy[index] == 0) {
        occupancy[index] = 1;
        frame_cells.push_back(index);
      }
    }

    if (hit_counts != nullptr) {
      for (const std::size_t index : frame_cells) {
        occupancy[index] = 0;

        if ((*hit_counts)[index] != 255U) {
          ++(*hit_counts)[index];
        }
      }
    }
  }

  // 对占据栅格做圆形膨胀
  void applyDilate(
    const Config & config,
    int width,
    int height,
    std::vector<uint8_t> & occupancy,
    std::size_t filtered_points)
  {
    if (config.dilate <= 0) {
      return;
    }

    const int radius = config.dilate;
    const int radius_squared = radius * radius;

    std::vector<std::pair<int, int>> occupied_cells;
    // 统计滤波后真实占据格通常远少于累计命中点数, 预留量按栅格总数封顶
    occupied_cells.reserve(
      std::min<std::size_t>(
        filtered_points,
        static_cast<std::size_t>(width) * static_cast<std::size_t>(height)));

    for (int iy = 0; iy < height; ++iy) {
      for (int ix = 0; ix < width; ++ix) {
        const std::size_t index =
          static_cast<std::size_t>(iy) *
          static_cast<std::size_t>(width) +
          static_cast<std::size_t>(ix);

        if (occupancy[index] != 0) {
          occupied_cells.emplace_back(ix, iy);
        }
      }
    }

    for (const auto & cell : occupied_cells) {
      const int sx = cell.first;
      const int sy = cell.second;

      const int x0 = std::max(0, sx - radius);
      const int x1 = std::min(width - 1, sx + radius);
      const int y0 = std::max(0, sy - radius);
      const int y1 = std::min(height - 1, sy + radius);

      for (int iy = y0; iy <= y1; ++iy) {
        for (int ix = x0; ix <= x1; ++ix) {
          const int dx = ix - sx;
          const int dy = iy - sy;

          if (dx * dx + dy * dy <= radius_squared) {
            occupancy[
              static_cast<std::size_t>(iy) *
              static_cast<std::size_t>(width) +
              static_cast<std::size_t>(ix)] = 1;
          }
        }
      }
    }
  }

  // 占据栅格 -> mono8 像素 (PGM 第 0 行在顶部, y 轴上下翻转)
  void occupancyToPixels(
    const std::vector<uint8_t> & occupancy,
    int width,
    int height,
    std::vector<uint8_t> & pixels)
  {
    const std::size_t pixel_count =
      static_cast<std::size_t>(width) *
      static_cast<std::size_t>(height);

    pixels.assign(pixel_count, 205);

    for (int iy = 0; iy < height; ++iy) {
      const int image_row = height - 1 - iy;

      for (int ix = 0; ix < width; ++ix) {
        const std::size_t source_index =
          static_cast<std::size_t>(iy) *
          static_cast<std::size_t>(width) +
          static_cast<std::size_t>(ix);

        const std::size_t target_index =
          static_cast<std::size_t>(image_row) *
          static_cast<std::size_t>(width) +
          static_cast<std::size_t>(ix);

        pixels[target_index] =
          occupancy[source_index] != 0 ? 0 : 205;
      }
    }
  }

  void renderPgm(
    const std::vector<Point> & cloud,
    const Config & config)
  {
    int width = 0;
    int height = 0;

    if (!computeMapSize(config, width, height)) {
      return;
    }

    std::vector<uint8_t> occupancy(
      static_cast<std::size_t>(width) *
      static_cast<std::size_t>(height), 0);

    std::size_t filtered_points = 0;

    accumulateCloud(cloud, config, width, height, occupancy, filtered_points);
    applyDilate(config, width, height, occupancy, filtered_points);

    std::vector<uint8_t> pixels;

    occupancyToPixels(occupancy, width, height, pixels);

    // 有订阅者时发布图像（mono8: 0=占据, 205=未知）
    if (image_publisher_ &&
      image_publisher_->get_subscription_count() > 0)
    {
      sensor_msgs::msg::Image image_msg;
      image_msg.header.stamp = get_clock()->now();
      image_msg.header.frame_id = "map";
      image_msg.height = static_cast<uint32_t>(height);
      image_msg.width = static_cast<uint32_t>(width);
      image_msg.encoding = "mono8";
      image_msg.is_bigendian = 0;
      image_msg.step = static_cast<uint32_t>(width);
      image_msg.data = pixels;
      image_publisher_->publish(image_msg);
    }

    const std::string temporary_file =
      config.output + ".tmp";

    {
      std::ofstream file(
        temporary_file,
        std::ios::binary | std::ios::trunc);

      if (!file) {
        RCLCPP_ERROR_THROTTLE(
          get_logger(),
          *get_clock(),
          2000,
          "无法创建 PGM 临时文件: %s",
          temporary_file.c_str());
        return;
      }

      file << "P5\n"
           << width << " " << height << "\n"
           << "255\n";

      file.write(
        reinterpret_cast<const char *>(pixels.data()),
        static_cast<std::streamsize>(pixels.size()));

      if (!file.good()) {
        RCLCPP_ERROR(
          get_logger(),
          "写入 PGM 失败: %s",
          temporary_file.c_str());
        return;
      }
    }

    if (std::rename(
        temporary_file.c_str(),
        config.output.c_str()) != 0)
    {
      RCLCPP_ERROR_THROTTLE(
        get_logger(),
        *get_clock(),
        2000,
        "无法替换 PGM 文件: %s",
        config.output.c_str());
      return;
    }

    RCLCPP_INFO_THROTTLE(
      get_logger(),
      *get_clock(),
      5000,
      "PGM 已更新: %s, 点数=%zu, 栅格=%dx%d",
      config.output.c_str(),
      filtered_points,
      width,
      height);
  }

  // 持久化历史地图: 最近 history_duration 秒点云按帧投票累积渲染,
  // 每个渲染周期重绘, 因此任何参数调整后都会自动更新
  void renderHistoryPgm(
    const std::deque<TimedCloud> & history,
    const Config & config)
  {
    // 清空历史(重建)后 history 为空: 仍渲染并发布一张"全未知"的空白图,
    // 让网页刷新按钮的效果立即可见, 随后随新点云逐帧重新累积。
    std::vector<const std::vector<Point> *> clouds;
    clouds.reserve(history.size());

    for (const auto & timed_cloud : history) {
      clouds.push_back(timed_cloud.points.get());
    }

    int width = 0;
    int height = 0;

    if (!computeMapSize(config, width, height)) {
      return;
    }

    std::vector<uint8_t> occupancy(
      static_cast<std::size_t>(width) *
      static_cast<std::size_t>(height), 0);
    // 命中帧数计数器: uint8 饱和计数(单帧每格最多计一次),
    // 历史窗口内的命中次数上限远小于 255
    std::vector<uint8_t> hit_counts(occupancy.size(), 0);

    std::size_t filtered_points = 0;

    for (const auto * cloud : clouds) {
      accumulateCloud(
        *cloud, config, width, height, occupancy, filtered_points, &hit_counts);
    }

    const uint8_t min_hits = static_cast<uint8_t>(
      std::min(255, std::max(1, config.history_min_hits)));

    for (std::size_t index = 0; index < occupancy.size(); ++index) {
      occupancy[index] = hit_counts[index] >= min_hits ? 1 : 0;
    }

    applyDilate(config, width, height, occupancy, filtered_points);

    std::vector<uint8_t> pixels;

    occupancyToPixels(occupancy, width, height, pixels);

    // 有订阅者时发布历史地图图像（mono8: 0=占据, 205=未知）
    if (history_image_publisher_ &&
      history_image_publisher_->get_subscription_count() > 0)
    {
      sensor_msgs::msg::Image image_msg;
      image_msg.header.stamp = get_clock()->now();
      image_msg.header.frame_id = "map";
      image_msg.height = static_cast<uint32_t>(height);
      image_msg.width = static_cast<uint32_t>(width);
      image_msg.encoding = "mono8";
      image_msg.is_bigendian = 0;
      image_msg.step = static_cast<uint32_t>(width);
      image_msg.data = pixels;
      history_image_publisher_->publish(image_msg);
    }

    const std::string temporary_file =
      config.history_output + ".tmp";

    {
      std::ofstream file(
        temporary_file,
        std::ios::binary | std::ios::trunc);

      if (!file) {
        RCLCPP_ERROR_THROTTLE(
          get_logger(),
          *get_clock(),
          2000,
          "无法创建历史 PGM 临时文件: %s",
          temporary_file.c_str());
        return;
      }

      file << "P5\n"
           << width << " " << height << "\n"
           << "255\n";

      file.write(
        reinterpret_cast<const char *>(pixels.data()),
        static_cast<std::streamsize>(pixels.size()));

      if (!file.good()) {
        RCLCPP_ERROR(
          get_logger(),
          "写入历史 PGM 失败: %s",
          temporary_file.c_str());
        return;
      }
    }

    if (std::rename(
        temporary_file.c_str(),
        config.history_output.c_str()) != 0)
    {
      RCLCPP_ERROR_THROTTLE(
        get_logger(),
        *get_clock(),
        2000,
        "无法替换历史 PGM 文件: %s",
        config.history_output.c_str());
      return;
    }

    RCLCPP_INFO_THROTTLE(
      get_logger(),
      *get_clock(),
      5000,
      "历史地图已更新: %s, 保留 %.1f s, 帧数=%zu, 点数=%zu, 栅格=%dx%d",
      config.history_output.c_str(),
      config.history_duration,
      history.size(),
      filtered_points,
      width,
      height);
  }

  void printConfig(const Config & config)
  {
    RCLCPP_INFO(
      get_logger(),
      "当前配置: resolution=%.4f, zmin=%.3f, zmax=%.3f, dilate=%d",
      config.resolution,
      config.zmin,
      config.zmax,
      config.dilate);

    RCLCPP_INFO(
      get_logger(),
      "地图范围: x=[%.2f, %.2f], y=[%.2f, %.2f]",
      config.xmin,
      config.xmax,
      config.ymin,
      config.ymax);

    RCLCPP_INFO(
      get_logger(),
      "历史地图: 保留 %.1f s, 最低命中帧数=%d, 每帧上限=%d, "
      "image=%s, 输出=%s",
      config.history_duration,
      config.history_min_hits,
      config.history_max_points_per_frame,
      history_image_topic_.c_str(),
      config.history_output.c_str());

    RCLCPP_INFO(
      get_logger(),
      "导航运动控制: 下发话题=%s (8 字节: control/shoot/tar_yaw/tar_pitch/vx/vy), "
      "里程计=%s, 全局路径=%s, 目标速度=%.2f m/s, 前视距离=%.2f m, "
      "到点阈值=%.2f m, 下发频率=%.1f Hz",
      motion_topic_.c_str(),
      odom_topic_.c_str(),
      global_plan_topic_.c_str(),
      motion_target_speed_,
      motion_lookahead_,
      motion_goal_tolerance_,
      motion_rate_hz_);
  }

private:
  std::string cloud_topic_;
  int render_period_ms_{200};

  std::mutex cloud_mutex_;
  std::vector<Point> latest_cloud_;
  bool received_cloud_{false};
  std::size_t cloud_frames_{0};

  std::mutex config_mutex_;
  Config config_{};
  bool config_changed_{false};

  rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr
    cloud_subscription_;

  rclcpp::TimerBase::SharedPtr render_timer_;
  rclcpp::TimerBase::SharedPtr warn_timer_;

  std::string image_topic_;
  rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr
    image_publisher_;

  std::string cloud_preview_topic_;
  int cloud_preview_max_points_{15000};
  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr
    cloud_preview_publisher_;

  std::deque<TimedCloud> history_;
  // 网页"刷新累计图"请求标志, 由参数回调置位, 渲染线程消费
  std::atomic<bool> history_reset_requested_{false};

  std::string history_image_topic_;
  rclcpp::Publisher<sensor_msgs::msg::Image>::SharedPtr
    history_image_publisher_;

  // ---------- 导航运动控制 (Nav2 全局路径 -> 8 字节运动帧) ----------
  // 运动帧话题: uint8[8] = control, shoot, tar_yaw(H/L), tar_pitch(H/L), vx, vy
  std::string motion_topic_;
  int motion_control_{1};          // control 位取值 (0=停止 / 1=运动)
  double motion_vx_scale_{50.0};   // vx 量化系数: 字节值 = vx(m/s) * scale
  double motion_vy_scale_{50.0};   // vy 量化系数: 字节值 = vy(m/s) * scale
  double motion_rate_hz_{20.0};    // 运动帧下发频率

  std::string odom_topic_;
  std::string global_plan_topic_;

  // 路径跟随参数 (全部以雷达坐标系为参考)
  double motion_target_speed_{0.30};
  double motion_lookahead_{0.45};
  double motion_yaw_kp_{1.20};
  double motion_goal_tolerance_{0.25};
  double motion_max_lateral_{0.0};
  double motion_slow_radius_{0.60};
  double motion_min_speed_{0.08};
  // 车体中心 -> 雷达原点 的平移, 表达在车体系 (与 lidar_to_base 互为反向量)
  double motion_base_to_lidar_x_{-0.239};
  double motion_base_to_lidar_y_{0.158};

  std::mutex motion_mutex_;
  bool motion_active_{false};        // 是否正在按路径运动
  double odom_x_{0.0};               // 最新雷达位姿 (map 系)
  double odom_y_{0.0};
  double odom_yaw_{0.0};
  bool odom_received_{false};
  rclcpp::Time odom_stamp_{0, 0, RCL_ROS_TIME};
  std::vector<Point> motion_plan_;   // Nav2 全局路径 (map 系)
  bool motion_plan_received_{false};
  rclcpp::Time motion_plan_stamp_{0, 0, RCL_ROS_TIME};

  rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr
    odom_subscription_;
  rclcpp::Subscription<nav_msgs::msg::Path>::SharedPtr plan_subscription_;
  rclcpp::TimerBase::SharedPtr motion_timer_;
  rclcpp::Publisher<std_msgs::msg::UInt8MultiArray>::SharedPtr
    motion_publisher_;

  // 网页"开始运动"/"停止运动"请求标志, 由参数回调置位, 运动线程消费
  std::atomic<bool> motion_start_requested_{false};
  std::atomic<bool> motion_stop_requested_{false};

  rclcpp::node_interfaces::OnSetParametersCallbackHandle::SharedPtr
    parameter_callback_handle_;
};

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);

  auto node = std::make_shared<RealtimePgmNode>();

  rclcpp::spin(node);

  rclcpp::shutdown();
  return 0;
}
